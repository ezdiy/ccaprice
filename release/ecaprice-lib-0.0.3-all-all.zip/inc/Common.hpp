/*
 * Copyright (C) 2011, 2012  
 * 	Dale Weiler
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#ifndef ESTL_COMMON_HDR
#define ESTL_COMMON_HDR

#if defined(i386)   || \
    defined(__i386) || \
    defined(__i386__)
    #define ARCH_I386
#endif
#if defined(__i486__)
    #define ARCH_I486
#endif
#if defined(__i568__)
    #define ARCH_I586
#endif
#if defined(__i686__)
    #define ARCH_I686
#endif
#if defined(_M_IX86)   || \
    defined(_X86_)     || \
    defined(ARCH_I386) || \
    defined(ARCH_I486) || \
    defined(ARCH_I568) || \
    defined(ARCH_I686)
    #define KFARCH_X86
#endif
#if defined(__amd64)   || \
    defined(__amd64__) || \
    defined(_M_X64)
    #define ARCH_AMD64
#endif
#if defined(__x86_64__)
    #define ARCH_X86_64
#endif
#if defined(ARCH_I386) || \
    defined(ARCH_I486) || \
    defined(ARCH_I586) || \
    defined(ARCH_I686) || \
    defined(ARCH_X86)
    #define ARCH_SIZE 32
#else
    #define ARCH_SIZE 64
#endif

// { pre:d } _ESTL_BEGIN_NAMESPACE,_ESTL_CLOSE_NAMESPACE
// { pre:d } UINTPTR_MIN,UINTPTR_MAX,distance
// { pre:d } _ESTL_PRIV_GLOBAL,_ESTL_PRIV_CLASS,_ESTL_PRIV_PLACE
// { pre:d } _ESTL_PRIV_BEGIN,_ESTL_PRIV_CLOSE,_ESTL_PRIV_CLASS_MAKE
// { pre:d } _ESTL_NOEXCEPT

#ifndef _STD_INC
#define _STD_INC
#   include <stdlib.h>
#   include <stdio.h>
#   include <stddef.h>
#   include <limits.h>
#   include <float.h>
#   include <wchar.h>
#   include <unistd.h>
#endif /* _STD_INC */

#define _ESTL_SCOPE_NAMESPACE estl
#define _ESTL_BEGIN_NAMESPACE namespace _ESTL_SCOPE_NAMESPACE {
#define _ESTL_CLOSE_NAMESPACE }

/*
 * Private internal macro tricks
 */
#define _ESTL_PRIV_GLOBAL     namespace
#define _ESTL_PRIV_CLASS      struct
#define _ESTL_PRIV_PLACE(x)   x hidden_estl_section
#define _ESTL_PRIV_BEGIN(x)   x _ESTL_PRIV_PLACE
#define _ESTL_PRIV_CLASS_MAKE friend class _ESTL_PRIV_PLACE;

/*
 * Understanding above macros
 */
 
// _ESTL_BEGIN_NAMESPACE                           namespace estl {
//		void foo() {}                             		void foo() {}
// _ESTL_CLOSE_NAMESPACE                           }

// _ESTL_BEGIN_NAMESPACE                           namespace estl {
// _ESTL_PRIV_PLACE(_ESTL_PRIV_GLOBAL)                 namespace hidden_estl_section {
//		void foo() {}                                      void foo() {}
//  }                                                  }
// _ESTL_PRIV_PLACE::foo();                            hidden_estl_section::foo();
// _ESTL_CLOSE_NAMESPACE                           }

// _ESTL_BEGIN_NAMESPACE                           namespace estl {
//     struct foo {                                    struct foo {
//         _ESTL_PRIV_BEGIN(_ESTL_PRIV_CLASS)              struct hidden_estl_section {
//	       static void bar(const foo& baz) {}                  static void bar(const foo& baz) {}
//         };                                              };
//         void baz() {                                    void baz() { 
//             _ESTL_PRIV_PLACE::bar(*this);                 hidden_estl_section::bar(*this);
//         }                                               }
//     }                                               }    
// _ESTL_CLOSE_NAMESPACE                           }

#if UCHAR_MAX == 0xFF
	typedef unsigned char  uint8_t;
#elif USHRT_MAX == 0xFF
	typedef unsigned short uint8_t;
#elif UINT_MAX == 0xFF
	typedef unsigned int uint8_t;
#elif ULONG_MAX == 0xFF
	typedef unsigned long uint8_t;
#endif
#if UCHAR_MAX == 0xFFFF
	typedef unsigned char uint16_t;
#elif USHRT_MAX == 0xFFFF
	typedef unsigned short uint16_t;
#elif UINT_MAX == 0xFFFF
	typedef unsigned int uint16_t;;
#elif ULONG_MAX == 0xFFFF
	typedef unsigned long uint16_t;
#endif
#if UCHAR_MAX == 0xFFFFFFFF
	typedef unsigned char uint32_t;
#elif USHRT_MAX == 0xFFFFFFFF
	typedef unsigned short uint32_t;
#elif UINT_MAX == 0xFFFFFFFF
	typedef unsigned int uint32_t;
#elif ULONG_MAX == 0xFFFFFFFF
	typedef unsigned long uint32_t;
#endif



// dirty hacks
#define UINTPTR_MIN 0
#define UINTPTR_MAX ULONG_MAX

#ifdef ESTL_CXX_OHX
	/**
	 * C++11 introduces a new keyword noexcept ...
	 **/
	#define _ESTL_NOEXCEPT noexcept
#else
	/**
	 * nothrow() has simaler behaviour as noexcept
	 **/
	#define _ESTL_NOEXCEPT nothrow()
#endif
#define _ESTL_THROW throw()


_ESTL_BEGIN_NAMESPACE
	template<typename T1, typename T2>
	inline ptrdiff_t distance(T1 i1, T2 i2) {
		return (i2 - i1);
	}
	// unvoid distance template specialization
	template<> inline ptrdiff_t distance      (void *p1,       void *p2) { return       (uint8_t*)p2-      (uint8_t*)p1; }
	template<> inline ptrdiff_t distance(const void *p1, const void *p2) { return (const uint8_t*)p2-(const uint8_t*)p1; }
	template<> inline ptrdiff_t distance      (void *p1, const void *p2) { return (const uint8_t*)p2-      (uint8_t*)p1; }
	template<> inline ptrdiff_t distance(const void *p1,       void *p2) { return       (uint8_t*)p2-(const uint8_t*)p1; }
_ESTL_CLOSE_NAMESPACE

#endif
