/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#include "../impl/algorithm"
#include "../impl/iostream"
#include "ut.hpp"

DEFTEST(for_each,{
	int sent[] = {0,0,0,0},pos=0;
	int data[] = {1,2,3,4};
	estl::cout << "  for_each:         ";
	estl::for_each(data, data+4, [&sent,&pos](int i)->void{
		estl::cout << i << " ";
		sent[pos++]=i;
	});
	estl::cout << estl::endl;
	DEFASSERT
	(
	    (sent[0]!=data[0] ||
		 sent[1]!=data[1] ||
		 sent[2]!=data[2]),
		"for_each: data does not match {1,2,3,4}"
	);
});
DEFTEST(find,{
	int data[] = {3,6,5,2,1,7};
	estl::cout << "  find:             ";
	estl::cout << *estl::find(data, data+4, 5) << estl::endl;
	DEFASSERT(
		(*estl::find(data, data+4, 5)!=5),
		"find: data does not match 5"
	);
});
DEFTEST(find_if,{
	int data[] = {10,25,40,55};
	int store  = *estl::find_if(data, data+4, 
		[](int i)->bool {
			return ((i%2)==1); // find odd data only
		}
	);
	estl::cout << "  find_if:          " << store << estl::endl;
	DEFASSERT(
		(store!=25), // 25 is first odd in data[] array
		"find_if: data does not equal 25"
	);
});
DEFTEST(advance,{
	int data[] = {10,20,30,40};
	int *dptr  =  data;
	estl::advance(dptr,2); //10(0),20(1),30(2) [0+2 = 2] data[2] = 30
	estl::cout << "  advance:          " << *dptr << estl::endl;
	DEFASSERT(
		(*dptr != 30),
		"advance: *dptr should be 30, but it's not"
	);
});
DEFTEST(find_end,{
	int data [] = {1,2,3,4,5,1,2,3,4,5};
	int match[] = {4,5,1};
	int store   = *estl::find_end(data, data+10, match, match+3);
	estl::cout << "  find_end:         " << store << estl::endl;
	DEFASSERT(
		(store!=4),
		"find_end: store does not equal 4 where {4,5,1} is in data"
	);
});
DEFTEST(find_end_predicate,{
	int data [] = {1,2,3,4,5,1,2,3,4,5};
	int match[] = {4,5,1};
	int store   = *estl::find_end(data, data+10, match, match+3,
		[](int i, int j)->bool {
		return (i==j);
	});
	estl::cout << "  find_end(p):      " << store << estl::endl;
	DEFASSERT(
		(store!=4),
		"find_end(p): store does not equal 4 where {4,5,1} is in data"
	);
});
DEFTEST(find_first_of,{
	int  data [] = {'a','b','c','A','B','C'};
	int  match[] = {'A','B','C'};
	int *dptr    = estl::find_first_of(data, data+6, match, match+3);
	estl::cout << "  find_first_of:    " << (char)*dptr << estl::endl;
	DEFASSERT(
		(*dptr != (int)'A'),
		"find_first_of: *dptr is not equal to `A`"
	);
});
DEFTEST(find_first_of_predicate,{
	int  data [] = {'a','b','c','A','B','C'};
	int  match[] = {'A','B','C'};
	int *dptr    = estl::find_first_of(data, data+6, match, match+3,[](int i, int j)->bool{
		return (i==j);
	});
	estl::cout << "  find_first_of(p): " << (char)*dptr << estl::endl;
	DEFASSERT(
		(*dptr != (int)'A'),
		"find_first_of(p): *dptr is not equal to `A`"
	);
});
DEFTEST(adjacent_find,{
	int  data[] = {10,20,30,30,20,10,10,20};
	int *dptr   = estl::adjacent_find(data, data+8);
	estl::cout << "  adjacent_find:    " << *dptr << estl::endl;
	DEFASSERT(
		(*dptr!=30),
		"adjacent_find: *dptr is not equal to `30`"
	);
});
DEFTEST(adjacent_find_predicate,{
	int  data[] = {10,20,30,30,20,10,10,20};
	int *dptr   = estl::adjacent_find(data, data+8, [](int i, int j)->bool {
		return (i==j);
	});
	estl::cout << "  adjacent_find(p): " << *dptr << estl::endl;
	DEFASSERT(
		(*dptr != 30),
		"adjacent_find(p): *dtr is not equal to `30`"
	);
});
DEFTEST(count,{
	int data[] = {10,20,30,30,20,10,10,20};
	int store  = static_cast<int>(
		estl::count(data, data+8, 10)
	);
	estl::cout << "  count:            " << store << estl::endl;
	DEFASSERT(
		(store!=3),
		"count: did not return 3"
	);
});
DEFTEST(count_if,{
	int data[] = {1,2,3,4,5,6,7,8,9};
	int store  = estl::count_if(data, data+9, 
		[](int i)->bool{
			return ((i%2)==1); // odd counting
		}
	);
	estl::cout << "  count_if:         "  << store << estl::endl;
	DEFASSERT(
		(store!=5),
		"count_if: failed to count 5 odd elements"
	);
});
DEFTEST(mismatch,{
	int data1[] = {10,20,30, 40,  50};
	int data2[] = {10,20,80,320,1024};
	estl::pair<int*,int*> pair_match = estl::mismatch(data1, data1+5, data2);
	estl::cout << "  mismatch:         " << *pair_match.first << estl::endl;
	DEFASSERT(
		!(pair_match.first >= data1   && 
		  pair_match.first <  data1+5 && 
		 *pair_match.first == 30),
		"mismatch: failed to return 30, [{10,20,30,...} vs {10,20,80,...}]"
	);
});
DEFTEST(mismatch_predicate,{
	int data1[] = {10,20,30, 40,  50};
	int data2[] = {10,20,80,320,1024};
	estl::pair<int*,int*> pair_match = estl::mismatch(data1, data1+5, data2,
		[](int i, int j)->bool {
			return (i==j);
		}
	);
	estl::cout << "  mismatch(p):      " << *pair_match.first << estl::endl;
	DEFASSERT(
		!(pair_match.first >= data1   && 
		  pair_match.first <  data1+5 && 
		 *pair_match.first == 30),
		"mismatch(p): failed to return 30, [{10,20,30,...} vs {10,20,80,...}]"
	);
});
DEFTEST(equal,{
	int data1[] = {10,20,30};
	int data2[] = {10,20,30};
	int isequ   = estl::equal(data1, data1+3, data2);
	estl::cout << "  equal:            " << ((isequ)?"true":"false") << estl::endl;
	DEFASSERT(
		!isequ,
		"equal: failed to return true"
	);
});
DEFTEST(equal_predicate,{
	int data1[] = {10,20,30};
	int data2[] = {10,20,30};
	int isequ   = estl::equal(data1, data1+3, data2,
		[](int i, int j)->bool {
			return (i==j);
		}
	);
	estl::cout << "  equal(p):         " << ((isequ)?"true":"false") << estl::endl;
	DEFASSERT(
		!isequ,
		"equal(p): failed to return true"
	);
});
DEFTEST(search,
{
	int  data [] = {10,20,30,40,50,60,70,80,90};
	int  match[] = {40,50,60,70};
	int *dptr    = estl::search(data, data+9, match, match+4);
	estl::cout << "  search:           " << *dptr << estl::endl;
	DEFASSERT(
		(*dptr!=40),
		"search: failed to find {40,50,60,70} in {10,20,30,40,50,60,70,80,90}"
	);
});
DEFTEST(search_predicate,{
	int  data [] = {10,20,30,40,50,60,70,80,90};
	int  match[] = {40,50,60,70};
	int *dptr    = estl::search(data, data+9, match, match+4,
		[](int i, int j)->bool {
			return (i==j);
		}
	);
	estl::cout << "  search(p):        " << *dptr << estl::endl;
	DEFASSERT(
		(*dptr!=40),
		"search(p): failed to find {40,50,60,70} in {10,20,30,40,50,60,70,80,90}"
	);
});
DEFTEST(search_n,{
	int  data[] = {10,20,30,30,20,10,10,20};
	int *dptr   = estl::search_n(data, data+8, 2, 30);
	estl::cout << "  search_n:         " << *dptr << estl::endl;
	DEFASSERT(
		(*dptr!=30),
		"search_n: failed to find two [30's]"
	);
});
DEFTEST(search_n_predicate,{
	int  data[] = {10,20,30,30,20,10,10,20};
	int *dptr   = estl::search_n(data, data+8, 2, 30,
		[](int i, int j)->bool {
			return (i==j);
		}
	);
	estl::cout << "  search_n(p):      " << *dptr << estl::endl;
	DEFASSERT(
		(*dptr!=30),
		"search_n(p): failed to find two [30's]"
	);
});
DEFTEST_SUITE();
