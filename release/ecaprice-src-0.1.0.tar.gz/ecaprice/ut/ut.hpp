/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef UT_HPP
#define UT_HPP
#include <ctype.h> // toupper()
int           testi              =  0 ;
const char* (*tests[1024])(void) = {0};
#define DEFTEST(name,...)                              \
    const char *test_##name() {                        \
        {__VA_ARGS__}                                  \
        return "OK";                                   \
    }                                                  \
    struct test_##name##_reg {                         \
        test_##name##_reg() {                          \
            tests[testi++] = &test_##name;             \
            estl::cout << "registered test: "<< #name; \
            estl::cout << estl::endl;                  \
        }                                              \
    } test_##name##_reg_dummy;
#define DEFASSERT(expr,msg) if((expr)) { return msg; }
inline bool runtests()
{
	bool ret = false;
	for(size_t i=0;i<1024;i++) {
		if(tests[i]!=0) {
			const char *run = tests[i]();
			if(strncmp(run, "OK", 2)!=0)
			{
				estl::cout<<"\n\nTEST FAILED: " << run << "\n\n";
				ret = true;
			}
		}
	}
	estl::cout << "};" << estl::endl;
	return ret;
}
inline void testprep_s(const char *F){
	estl::cout << "----------------------------"  << estl::endl;
	estl::cout << " running "<< testi <<" tests"  << estl::endl;
	estl::cout << "----------------------------"  << estl::endl;
	estl::cout <<                                    estl::endl;
	
	size_t leng     =  0;
	char   file[255]= {0};
	memcpy (file, F, 255);
	memcpy (file, file+3, 252);  // get rid of `ut/`
	file [strlen(file)-4]='\0';  // get rid of `.cpp, or .hpp`
	leng= strlen(file);
	
	// make uppercase
	for(size_t i=0; i<leng;i++)
		file[i]=toupper(file[i]);
		
	estl::cout << file << estl::endl;
	estl::cout << "{"  << estl::endl;
}
// expansion inside .cpp file only :)
#define testprep() testprep_s(__FILE__)
#define DEFTEST_SUITE() \
	int main()          \
	{                   \
		testprep();     \
		if (runtests()) \
			estl::cout << "test(s) failed" << estl::endl; \
		else                                              \
			estl::cout << "test(s) passed" << estl::endl; \
		return 1;                                         \
	}
#endif
