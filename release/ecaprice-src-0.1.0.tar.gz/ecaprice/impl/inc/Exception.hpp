/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_EXCEPTION_HDR
#define ESTL_EXCEPTION_HDR
_ESTL_BEGIN_NAMESPACE

// { pre:d } ESTL_EXCEPTION_DEFAULTONE_CREATE
// { pre:d } ESTL_EXCEPTION_INHERITDEF_CREATE
// { pre:d } ESTL_EXCEPTION_ERRORSTATE_CREATE
// { pre:d } exception,bad_exception,bad_cast
// { pre:d } logic_error,runtime_error,domain_error
// { pre:d } invalid_argument,out_of_range,range_error
// { pre:d } overflow_error,underflow_error

#define ESTL_EXCEPTION_DEFAULTONE_CREATE(name) \
class name : public exception {                \
public:                                        \
    const char* what() const throw() {         \
        return #name;                          \
    }                                          \
}
#define ESTL_EXCEPTION_INHERITDEF_CREATE(t,nm) \
class t : public nm {                          \
public:                                        \
             t(            ){}                 \
    explicit t(const char *){}                 \
    const char* what() const throw() {         \
        return #t;                             \
    }                                          \
}
#define ESTL_EXCEPTION_ERRORSTATE_CREATE(name) \
        ESTL_EXCEPTION_INHERITDEF_CREATE(name, exception)

// default exception class
class exception
{
public:
    exception           (                ) throw() {               }
    exception           (const exception&) throw() {               }
    exception& operator=(const exception&) throw() { return *this; }

    // Return error string.
    virtual const char* what() const throw();
};

// create exceptions from base
ESTL_EXCEPTION_DEFAULTONE_CREATE(bad_exception);
ESTL_EXCEPTION_DEFAULTONE_CREATE(bad_cast);
ESTL_EXCEPTION_DEFAULTONE_CREATE(bad_typeid);
// create error_state inheritable classes deriving exception
ESTL_EXCEPTION_ERRORSTATE_CREATE(logic_error);
ESTL_EXCEPTION_ERRORSTATE_CREATE(runtime_error);
// create exceptions from inherits
ESTL_EXCEPTION_INHERITDEF_CREATE(domain_error,     logic_error  );
ESTL_EXCEPTION_INHERITDEF_CREATE(invalid_argument, logic_error  );
ESTL_EXCEPTION_INHERITDEF_CREATE(length_error,     logic_error  );
ESTL_EXCEPTION_INHERITDEF_CREATE(out_of_range,     logic_error  );
ESTL_EXCEPTION_INHERITDEF_CREATE(range_error,      runtime_error);
ESTL_EXCEPTION_INHERITDEF_CREATE(overflow_error,   runtime_error);
ESTL_EXCEPTION_INHERITDEF_CREATE(underflow_error,  runtime_error);

#undef ESTL_EXCEPTION_DEFAULTONE_CREATE
#undef ESTL_EXCEPTION_ERRORSTATE_CREATE
#undef ESTL_EXCEPTION_INHERITDEF_CREATE

_ESTL_CLOSE_NAMESPACE
#endif
