/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_NUMERIC_HDR
#define ESTL_NUMERIC_HDR
#include "Iterator.hpp"
_ESTL_BEGIN_NAMESPACE

/** PREVENT MACRO MOLESTATION **/
// { pre:d } accumulate,adjacent_difference,inner_product, partial_sum

// Returns the result of accumulating all the values in the 
// range [first,last) to init.
template<typename I, typename T>
T accumulate(I first, I last, T init)
{
    while(first != last)
        init += *first++;
    return init;
}

// Returns the result of accumulating all the values in the 
// range [first,last) to init, using a binary predication
// to modify the type of accumulation.
template<typename I, typename T, typename P>
T accumulate(I first, I last, T init, P pred)
{
	while(first != last)
		init = pred(init, *first++);
	return init;
}

// Assigns to every element in the range starting at result the 
// difference between its corresponding elements in the range [first,last)
// and the one preceding it (except for *result which is assigned *first).
template<typename I, typename O>
O adjacent_difference(I first, I last, O result)
{
    typename iterator_traits<I>::value_type val, prev;
    *result ++ = prev = *first++;

    while(first != last)
    {
        val       = *first++;
        *result++ = val - prev;
        prev      = val;
    }
    return result;
}
//binary_op version
template<typename I, typename O, typename B>
O adjacent_difference(I first, I last, O result, B b)
{
    typename iterator_traits<I>::value_type val, prev;
    *result ++ = prev = *first++;

    while(first != last)
    {
        val       = *first++;
        *result++ = b(val,prev);
        prev      = val;
    }
    return result;
}

// Returns the result of accumulating init with the inner products of the
// pairs formed by the elements of two ranges starting at first1 and first2.
template<typename I1, typename I2, typename T>
T inner_product(I1 first1, I1 last1,
                I2 first2,  T init)
{
    while(first1 != last1)
        init += (*first1++)*(*first2++);
    return init;
}
//binary_op version
template<typename I1, typename I2, typename T, typename B1, typename B2>
T inner_product(I1 first1, I1 last1,
                I2 first2,  T init ,
                B1 binop1, B2 binop2)
{
    while(first1 != last1)
        init = binop1(init, binop2(*first1++, *first2++));
    return init;
}

// Assigns to every element in the range starting at result the partial 
// sum of the corresponding elements in the range [first,last).
template<typename I, typename O>
O partial_sum(I first, I last, O result)
{
    typename iterator_traits<I>::value_type val;
    *result++ = val = *first++;

    while(first != last)
        *result++ = val = val + *first++;
    return result;
}
//binary_op version
template<typename I, typename O, typename B>
O partial_sum(I first, I last, O result, B b)
{
    typename iterator_traits<I>::value_type val;
    *result++ = val = *first++;

    while(first != last)
        *result++ = val = b(val,*first++);
    return result;
}

_ESTL_CLOSE_NAMESPACE
#endif
