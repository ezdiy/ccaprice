/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/
#ifndef ESTL_PAIR_HPP
#define ESTL_PAIR_HPP
#ifdef  ESTL_CXX_OHX
#	include "TypeTraits.hpp"
#endif
_ESTL_BEGIN_NAMESPACE
/** Prevent macro molestation: util/preprocess.cpp for refrence **/
// { pre:d } T1,T2,pair,C1,C2,first,second
template<typename T1, typename T2>
struct pair
{
    typedef T1 first_type;
    typedef T2 second_type;

    T1 first;
    T2 second;

    pair() :
        first (T1()),
        second(T2())
    {}

    pair(const T1& a, const T2& b) :
        first (a),
        second(b)
    {}
    
    // assignment operators
    pair& operator=(const pair<T1,T2>& rhs)
    {
		first  = rhs.first;
		second = rhs.second;
		return *this;
	}
	
	// for implicitally castable types
	// like int to long, or float to double
	template<typename C1, typename C2>
	pair& operator=(const pair<C1,C2>& rhs)
	{
		first  = rhs.first;
		second = rhs.second;
		return *this;
	}
#ifndef ESTL_CXX_OHX
	// Construct pair object from members of any
    // implicitly-convertible types, as well as
    // same types.
    template <typename C1,typename C2>
    pair(const pair<C1,C2> &rhs) :
        first (rhs.first ),
        second(rhs.second)
    {}
#else
	template <
		typename C1,
		typename C2,
		typename = typename enable_if <
			_ESTL_PRIV_PLACE::template_and <
				is_convertible <const C1&,T1>,
				is_convertible <const C2&,T2>
			>::value
		>::type
	>
	constexpr pair(const pair<C1, C2>& rhs) :
		first (rhs.first ),
		second(rhs.second)
	{}
	/// pair::swap()
	template<typename C1, typename C2>
	void swap(pair<C1,C2>& x, pair<C1,C2>& y) noexcept(noexcept(x.swap(y))) {
		x.swap(y);
	}
#endif
};

/** comparison overloaded operators **/
template<typename T1, typename T2>
inline bool operator==(const pair<T1,T2>& x, const pair<T1, T2>& y) {
    return x.first == y.first && x.second == y.second;
}
template<typename T1, typename T2>
inline bool operator <(const pair<T1,T2>& x, const pair<T1, T2>& y) {
    return x.first < y.first || (!(y.first < x.first) && x.second < y.second);
}

/** helper function(s) **/
template<typename T1, typename T2>
inline pair<T1,T2> make_pair(T1 x, T2 y) {
    return pair<T1,T2>(x,y);
}
_ESTL_CLOSE_NAMESPACE
#endif
