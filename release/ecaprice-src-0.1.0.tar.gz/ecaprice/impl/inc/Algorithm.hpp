/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_ALGORITHMS_HDR
#define ESTL_ALGORITHMS_HDR

/*
 * `typename I`  implies a input iterator
 * `typename F`  implies a function 
 * `typename F#` implies a forward iterator [example (typename F1, typename F2 ... )]
 * `typename P`  implies a predication
 * `typename B#` implies a bidirectional iterator [ example (typename B1, typename B2 ... )] 
 * `typename T`  implies any type 
 *
 *
 *  refrence: http://www.cplusplus.com/reference/algorithm/ 
 */

/** Prevent macro molestation: util/preprocess.cpp for refrence **/
// { pre:d } I,F,P,B,T
// { pre:d } F1,F2,F3,F4,F5,F6
// { pre:d } P1,P2,P3,P4,P5,P6
// { pre:d } B1,B2,B3,B4,B5,B6
//Non-modifying sequence operations macro-molestation protection
// { pre:d } for_each,find,find_if,find_end
// { pre:d } find_first_of,adjacent_find,count,count_if
// { pre:d } mismatch,equal,search,search_n
//Modifying sequence operations macro-molestation protection
// { pre:d } copy,copy_backward,swap,swap_ranges,iter_swap
// { pre:d } transform,replace,replace_if,replace_copy
// { pre:d } replace_copy_if,fill,fill_n,generate,generate_n
// { pre:d } remove,remove_if,remove_copy,remove_copy_if,unique
// { pre:d } unique_copy,reverse,reverse_copy,rotate,rotate_copy
// { pre:d } partition
//Binary search operations macro-molestation protection
// { pre:d } lower_bound,upper_bound,equal_range,binary_search
//Miscoperationsmacro-molestationprotection
// { pre:d } min,max

#include "Common.hpp"
#include "Pair.hpp"
#include "Iterator.hpp"
_ESTL_BEGIN_NAMESPACE

// Advances an iterator by `n` elements
template<typename I, typename D>
void advance(I& i, D n)
{
	i += n;
}


// Applies function f to each of the elements in the range [first,last).
template<typename I, typename F>
F for_each(I first, I last, F f)
{
    for(; first != last; ++first) f(*first);
    return f;
}

// Returns an iterator to the first element in the range [first,last) 
// that compares equal to value, or last if not found.
template<typename I, typename T>
I find(I first, I last, const T& v)
{
    for(; first != last; ++first)
        if(*first == v) break;
    return first;
}

// Returns an iterator to the first element in the range [first,last) 
// for which applying p to it, is true.
template<typename I, typename P>
I find_if(I first, I last, P p)
{
    for(; first != last; first++)
        if(p(*first)) break;
    return first;
}

// Searches the range  [first1,last1) for the last occurrence of the 
// sequence defined by [first2,last2), and returns an iterator to its 
// first element.
template<typename F1, typename F2>
F1 find_end(F1 first1, F1 last1,
            F2 first2, F2 last2)
{
    F1 it1, l, r;
    F2 it2;

    l = first1;
    advance(l, 1 + distance(first1, last1) - distance(first2, last2));
    r = last1;

    while(first1 != l)
    {
        it1 = first1; it2 = first2;
        while(*it1 == *it2)
        {
            ++it1; ++it2;
            if(it2 == last2)
            {
                r = first1;
                break;
            }
        }
        ++first1;
    }
    return r;
}
// predicate version
template<typename F1, typename F2, typename P>
F1 find_end(F1 first1, F1 last1,
            F2 first2, F2 last2, P p)
{
    F1 it1, l, r;
    F2 it2;

    l = first1;
    advance(l, 1 + distance(first1, last1) - distance(first2, last2));
    r = last1;

    while(first1 != l)
    {
        it1 = first1; it2 = first2;
        while(p(*it1,*it2))
        {
            ++it1; ++it2;
            if(it2 == last2)
            {
                r = first1;
                break;
            }
        }
        ++first1;
    }
    return r;
}

// Returns an interator to the first occurrence in the range 
// [first1,last1) of any of the elements in [first2,last2).
template<typename F1, typename F2>
F1 find_first_of(F1 first1, F1 last1,
                 F2 first2, F2 last2)
{
    for(; first1 != last1; ++first1)
    {
        for(F2 it = first2; it != last2; ++it)
        {
            if(*it == *first1)
                return first1;
        }
    }
    return last1;
}
// predicate version
template<typename F1, typename F2, typename P>
F1 find_first_of(F1 first1, F1 last1,
                 F2 first2, F2 last2, P p)
{
    for(; first1 != last1; ++first1)
    {
        for(F2 it = first2; it != last2; ++it)
        {
            if(p(*it,*first1))
                return first1;
        }
    }
    return last1;
}

// Searches the range [first,last) for the first occurrence of two 
// consecutive equal elements, and returns an iterator to the first of
// these two elements.
template<typename F1>
F1 adjacent_find(F1 first, F1 last)
{
    if(first != last)
    {
        F1 next = first; ++next;
        while(next != last)
        {
            if(*first++ == *next++)
                return first;
        }
    }
    return last;
}
// predicate version
template<typename F1, typename P>
F1 adjacent_find(F1 first, F1 last, P p)
{
    if(first != last)
    {
        F1 next = first; ++next;
        while(next != last)
        {
            if(p(*first++,*next++))
                return first;
        }
    }
    return last;
}

// Returns the number of elements in the range [first,last) 
// that compare equal to v.
template<typename I, typename T>
ptrdiff_t count(I first, I last, const T& v)
{
    ptrdiff_t r = 0;
    while(first != last)
        if(*first++ == v) ++r;
    return r;
}

// Returns the number of elements in the range [first,last) for which 
// condition p is true.
template<typename I, typename P>
ptrdiff_t count_if(I first, I last, P p)
{
    ptrdiff_t r = 0;
    while(first != last)
        if(p(*first++)) ++r;
    return r;
}

// Compares the elements in the range [first1,last1) against those in 
// the range beginning at first2 sequentially, and returns where the 
// first mismatch happens.
template<typename I1, typename I2>
pair<I1,I2> mismatch(I1 first1, I1 last1, I2 first2)
{
    while(first1 != last1 && *first1 == *first2)
    {
		++first1;
		++first2;
    }
    return make_pair(first1, first2);
}
// predicate version
template<typename I1, typename I2, typename P>
pair<I1,I2> mismatch(I1 first1, I1 last1, I2 first2, P p)
{
    while(first1 != last1 && bool(p(*first1,*first2)))
    {
        ++first1;
        ++first2;
    }
    return make_pair(first1, first2);
}

// Compares the elements in the range [first1,last1) with those in the 
// range beginning at first2, and returns true if the elements in both 
// ranges are considered equal.
template<typename I1, typename I2>
bool equal(I1 first1, I1 last1, I2 first2)
{
    while(first1 != last1)
    {
        if(*first1 != *first2)
            return false;
        ++first1;
        ++first2;
    }
    return true;
}
//predicate version
template<typename I1, typename I2, typename P>
bool equal(I1 first1, I1 last1, I2 first2, P p)
{
    while(first1 != last1)
    {
        if(!p(*first1,*first2))
            return false;
        ++first1;
        ++first2;
    }
    return true;
}

// Searches the range [first1,last1) for the first occurrence of the
// sequence defined by [first2,last2), and returns an iterator to its
// first element.
template<typename F1, typename F2>
F1 search(F1 first1, F1 last1,
          F2 first2, F2 last2)
{
    F1 it1, l;
    F2 it2;

    l = first1;
    advance(l, 1 + distance(first1,last1) - distance(first2,last2));

    while(first1 != l)
    {
        it1 = first1;
        it2 = first2;
        while(*it1 == *it2)
        {
            ++it1; ++it2;
            if(it2 == last2)
                return first1;
        }
        ++first1;
    }
    return last1;
}
// predicate version
template<typename F1, typename F2, typename P>
F1 search(F1 first1, F1 last1,
          F2 first2, F2 last2, P p)
{
    F1 it1, l = first1;
    F2 it2;
    advance(l, 1 + distance(first1,last1) - distance(first2,last2));

    while(first1 != l)
    {
        it1 = first1;
        it2 = first2;
        while(p(*it1,*it2))
        {
            ++it1; ++it2;
            if(it2 == last2)
                return first1;
        }
        ++first1;
    }
    return last1;
}

// Searches the range [first,last) for a succession of count elements,
// each of them comparing equal (or some other predicate) to value.
template<typename F1, typename S, typename T>
F1 search_n(F1 first, F1 last, S count, const T& v)
{
    F1 it, l = first;
    S  i;
    advance(l, distance(first,last)-count);

    while(first != l)
    {
        it = first; i = 0;
        while(*it == v)
        {
            ++it;
            if(++i == count)
                return first;
        }
        ++first;
    }
    return last;
}
// predicate version
template<typename F1, typename S, typename T, typename P>
F1 search_n(F1 first, F1 last, S count, const T& v, P p)
{
    F1 it, l = first;
    S  i;
    advance(l, distance(first,last)-count);

    while(first != l)
    {
        it = first; i = 0;
        while(p(*it,v))
        {
            ++it;
            if(++i == count)
                return first;
        }
        ++first;
    }
    return last;
}

/** MODIFYING SEQUENCE OPERATIONS **/

// Copies the elements in the range [first,last) into a range beginning
// at result.
template<typename I, typename O>
O copy(I first, I last, O result)
{
    while(first != last) *result++ = *first++;
    return result;
}

// Copies the elements in the range [first,last) into a range whose last
// element is result. The function begins by copying *(last-1) into 
// *(result-1), and then follows backwards by the elements preceeding 
// these, until first is reached (and including it).
template<typename B1, typename B2>
B2 copy_backward(B1 first, B1 last, B2 result)
{
    while(last != first)
        *(--result) = *(--last);
    return result;
}

// Assigns the content of a to b and the content of b to a.
template<typename T>
void swap(T& a, T& b) {
    T c(a); a=b; b=c;
}

// Swaps the values of each of the elements in the range [first1,last1)
// with those of their respective elements in the range beginning at first2.
template<typename F1, typename F2>
F2 swap_ranges(F1 first1, F1 last1, F2 first2)
{
    while(first1 != last1)
        swap(*first1++, *first2++);
    return first2;
}

// Assigns the content of *a to *b and the content of *b to *a.
template<typename F1, typename F2>
void iter_swap(F1 a, F2 b) {
    swap(*a, *b);
}

// Apply function to range
template<typename I, typename O, typename U>
O transform(I first1, I last1, O result, U op)
{
    while(first1 != last1)
        *result++ = op(*first1++);
    return result;
}
// binary_op version
template<typename I1, typename I2, typename O, typename B>
O transform(I1 first1, I1 last1, I2 first2, O result, B bop)
{
    while(first1 != last1)
        *result++ = bop(*first1++, *first2++);
    return result;
}

// Sets all the elements in the range [first,last) whose current value 
// equals old_value to a value of new_value.
template<typename F, typename T>
void replace(F first, F last, const T& old_value, const T& new_value)
{
    for(; first != last; ++first)
        if(*first == old_value) *first = new_value;
}

// Sets all those elements in the range [first,last) for which p 
// returns true when applied to its value, to a value of new_value.
template<typename F, typename P, typename T>
void replace_if(F first, F last, P p, const T& new_value)
{
    for(; first != last; ++first)
        if(p(*first)) *first = new_value;
}

// Copies the values of the elements in the range [first,last) to the 
// range positions beginning at result, replacing the appearances of 
// old_value by new_value.
template<typename I, typename O, typename T>
O replace_copy(I first, I last, O result, const T& old_value, const T& new_value)
{
    for(; first != last; ++first, ++result)
        *result = (*first == old_value) ? new_value : *first;
    return result;
}


// Copies the values of the elements in the range [first,last) to the 
// range positions beginning at location pointed by result, replacing 
// those where p is true by new_value.
template<typename I, typename O, typename P, typename T>
O replace_copy_if(I first, I last, O result, P p, const T& new_value)
{
    for(; first != last; ++first, ++result)
        *result = (p(*first)) ? new_value : *first;
    return result;
}

// Sets value to all elements in the range [first,last).
template<typename F, typename T>
void fill(F first, F last, const T& value)
{
    while(first != last)
        *first++ = value;
}

// Sets value to the first n elements in the sequence pointed by first.
template<typename O, typename S, typename T>
void fill_n(O first, S n, const T& value)
{
    for(; n > 0; --n)
        *first++ = value;
}

// Sets the value of the elements in the range [first,last) to the value 
// returned by successive calls to gen.
template<typename F, typename G>
void generate(F first, F last, G gen)
{
    while(first != last)
        *first++ = gen();
}

// Sets the value of the first n elements in the sequence pointed by 
// first to the value returned by successive calls to gen.
template<typename O, typename S, typename G>
void generate_n(O first, S n, G gen)
{
    for(; n > 0; --n)
        *first++ = gen();
}

// Removes from the range [first,last) the elements with a value equal 
// to value and returns an iterator to the new end of the range, which 
// now includes only the values not equal to value.
template<typename F, typename T>
F remove(F first, F last, const T& value)
{
    F result = first;
    for(; first != last; ++first)
    {
        if(!(*first++ == value))
            *result++ = *first;
    }
    return result;
}

// Removes from the range [first,last) the elements for which p 
// applied to its value is true, and returns an iterator to the new end
// of the range, which now includes only the values for which p was 
// false.
template<typename F, typename P>
F remove_if(F first, F last, P p)
{
    F result = first;
    for(; first != last; ++first)
    {
        if(!p(*first))
            *result++ = *first;
    }
    return result;
}

// Copies the values of the elements in the range [first,last) to the 
// range positions beginning at result, except for the elements that 
// compare equal to value, which are not copied.
template<typename I, typename O, typename T>
O remove_copy(I first, I last, O result, const T& value)
{
    for(; first != last; ++first)
    {
        if(!(*first == value))
            *result++ = *first;
    }
    return result;
}

// Copies the values of the elements in the range [first,last) to the 
// range positions beginning at result, except those for which p is true,
// which are not copied.
template<typename I, typename O, typename P>
O remove_copy_if(I first, I last, O result, P p)
{
    for(; first != last; ++first)
    {
        if(!p(*first))
            *result++ *first;
    }
    return result;
}

// Removes the duplicate consecutive elements from the range [first,last).
// This is done by removing all the elements that compare equal to the 
// element right preceding them (only the first element in each group of
// consecutive equal elements is kept).
template<typename F>
F unique(F first, F last)
{
    F result = first;
    while(++first != last)
    {
        if(!(*result == *first))
            *(++result) = *first;
    }
    return ++result;
}
//predicate version
template<typename F, typename P>
F unique(F first, F last, P p)
{
    F result = first;
    while(++first != last)
    {
        if(!p(*result, *first))
            *(++result) = *first;
    }
    return ++result;
}

// Copies the values of the elements in the range [first,last) to the 
// range positions beginning at result, except for the duplicate 
// consecutive elements, which are not copied
template<typename I, typename O>
O unique_copy(I first, I last, O result)
{
    typename estl::iterator_traits<I>::value_type value = *first;
    *result = *first;
    while(++first != last)
    {
        if(!(value == *first))
            *(++result) = value = *first;
    }
    return ++result;
}
//predicate version
template<typename I, typename O, typename P>
O unique_copy(I first, I last, O result, P p)
{
    typename estl::iterator_traits<I>::value_type value = *first;
    *result = *first;
    while(++first != last)
    {
        if(!p(value,*first))
            *(++result) = value = *first;
    }
    return ++result;
}

// Reverses the order of the elements in the range [first,last).
template<typename B>
void reverse(B first, B last)
{
    while((first != last) && (first != --last))
        swap(*first++,*last);
}

// Copies the values of the elements in the range [first,last) to the
// range positions beginning at result, but reversing its order.
template<typename B, typename O>
O reverse_copy(B first, B last, O result)
{
    while(first != last)
        *result++ = *--last;
    return result;
}

// Rotates the order of the elements in the range [first,last), in such 
// a way that the element pointed by middle becomes the new first element.
template<typename F>
void rotate(F first, F middle, F last)
{
    F next = middle;
    while(first != last)
    {
        swap(*first++, *next++);

             if(next  == last  ) next   = middle;
        else if(first == middle) middle = next;
    }
}

// Copies the values of the elements in the range [first,last) to the 
// range positions beginning at result, but rotating the order of the 
// elements in such a way that the element pointed by middle becomes 
// the first element in the resulting range.
template<typename F, typename O>
O rotate_copy(F first, F middle, F last, O result)
{
    result = copy(middle,last  ,result);
    return   copy(first ,middle,result);
}

// Rearranges the elements in the range [first,last) randomly.
template<typename RA, typename RN>
void random_shuffle(RA first, RA last, RN& rand)
{
    typename estl::iterator_traits<RA>::difference_type i,n = (last - first);
    for(i=n-1; i>0; --i)
        swap(first[i], first[rand(i+1)]);
}

// Rearranges the elements in the range [first,last), in such a way that
// all the elements for which p returns true precede all those for 
// which it returns false. The iterator returned points to the first 
// element of the second group.
template<typename B, typename P>
B partition(B first, B last, P p)
{
    while(true)
    {
        while(first != last && p(*first)) ++first;
        if(first == last--) 
            break;
        while(first != last && !p(*last)) --last;
        if(first == last  )
            break;
        swap(*first++, *last);
    }
    return first;
}

/* min/max */
template<typename T>            const T& min(const T& a,const T& b)     { return  (a<b)?a:b; }
template<typename T,typename C> const T& min(const T& a,const T& b,C c) { return c(a,b)?a:b; }
template<typename T>            const T& max(const T& a,const T& b)     { return  (b<a)?a:b; }
template<typename T,typename C> const T& max(const T& a,const T& b,C c) { return c(b,a)?a:b; }

/** BINARY SEARCH **/
// Returns an iterator pointing to the first element in the sorted range
// [first,last) which does not compare less than value
template<typename F, typename T>
F lower_bound(F first, F last, const T& value)
{
    F it;
    typename estl::iterator_traits<F>::distance_type step, count = distance(first,last);
    while(count > 0)
    {
        it   = first;
        step = count/2;
        advance(it,step);

        if(*it < value)
        {
            first  = ++it;
            count -= step + 1;
        } else { 
            count = step;
        }
    }
    return first;
}
//predicate version
template<typename F, typename T, typename P>
F lower_bound(F first, F last, const T& value, P p)
{
    F it;
    typename estl::iterator_traits<F>::distance_type step, count = distance(first,last);
    while(count > 0)
    {
        it   = first;
        step = count/2;
        advance(it,step);

        if(p(*it,value))
        {
            first  = ++it;
            count -= step + 1;
        } else { 
            count = step;
        }
    }
    return first;
}

// Returns an iterator pointing to the first element in the sorted range 
// [first,last) which compares greater than value. The comparison is done
//  using either operator< for the first version, or comp for the second.
template<typename F, typename T>
F upper_bound(F first, F last, const T& value)
{
    F it;
    typename estl::iterator_traits<F>::distance_type step, count = distance(first, last);
    while(count > 0)
    {
        it   = first;
        step = count/2;
        advance(it, step);

        if(!(value<*it))
        {
            first  = ++it;
            count -= step + 1;
        } else {
            count = step;
        }
    }
    return first;
}
// predicate version
template<typename F, typename T, typename P>
F upper_bound(F first, F last, const T& value, P comp)
{
    F it;
    typename estl::iterator_traits<F>::distance_type step, count = distance(first, last);
    while(count > 0)
    {
        it   = first;
        step = count/2;
        advance(it, step);

        if(!comp(value<*it))
        {
            first  = ++it;
            count -= step + 1;
        } else {
            count = step;
        }
    }
    return first;
}

// Returns the bounds of the largest subrange that includes all the 
// elements of the [first,last) with values equivalent to value.
template<typename F, typename T>
estl::pair<F, F> equal_range(F first, F last, const T& value)
{
    F it = lower_bound(first, last, value);
    return make_pair  (it, estl::upper_bound(it, last, value));
}

// Returns true if an element in the range [first,last) is equivalent 
// to value, and false otherwise.
template<typename F, typename T>
bool binary_search(F first, F last, const T& value)
{
    first = lower_bound(first,last,value);
    return (first != last && !(value<*first));
}
//predicate version
template<typename F, typename T, typename P>
bool binary_search(F first, F last, const T& value, P comp)
{
    first = lower_bound(first,last,value);
    return (first != last && !comp(value<*first));
}

_ESTL_CLOSE_NAMESPACE
#endif
