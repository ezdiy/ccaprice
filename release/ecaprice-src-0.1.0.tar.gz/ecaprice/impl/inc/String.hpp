/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_STRING_HDR
#define ESTL_STRING_HDR
#include "Common.hpp"
#include <string.h>      // strlen()
#include "Exception.hpp" // out_of_range
#include "Iterator.hpp"  // reverse_iterator<T>
#include "Limits.hpp"    // numeric_limits<T>
_ESTL_BEGIN_NAMESPACE

template<typename T>
class basic_string
{
public:
	typedef T value_type;
};

template<>
class basic_string<char> 
{
	/*
	 *	Synopsis:
	 *	Things with no (x) are TODO
	 *	where as things with (x) are implemented
	 *	and things with (s) are semi-implemented
	 * 
	 * 	Iterators:
	 * 		begin     (x)
	 * 		end       (x)
	 * 		rbegin    (x)
	 * 		rend      (x)
	 * 
	 *  Capacity:
	 * 		size      (x)
	 * 		length    (x)
	 * 		max_size  (x)
	 * 		resize    (x)
	 * 		capacity  (x)
	 * 		reserve   (x)
	 * 		clear     (x)
	 * 		empty     (x)
	 * 	
	 *  Element access:
	 * 		operator[](x)
	 * 		at        (x)
	 * 
	 *  Modifiers:
	 * 		operator+=(x)
	 * 		append    (s)
	 * 		push_back (x)
	 * 		assign    (s)
	 * 		insert    ( )
	 * 		erase     ( )
	 * 		replace   ( )
	 * 		swap      (x)
	 * 
	 *  String operations:
	 * 		c_str             (x)
	 * 		data              (x)
	 * 		get_allocator     ( )
	 * 		copy              ( )
	 * 		find              ( )
	 *		rfind             ( )
	 * 		find_first_of     ( )
	 * 		find_last_of      ( )
	 * 		find_first_not_of ( )
	 * 		find_last_not_of  ( )
	 * 		substr            ( )
	 * 		compare           ( )
	 */
public:
	typedef char                                   value_type;
	typedef size_t                                 size_type;
	typedef value_type*                            iterator;
	typedef const value_type*                      const_iterator;
	typedef int                                    alloc_type;
	typedef estl::reverse_iterator<iterator>       reverse_iterator;
	typedef estl::reverse_iterator<const_iterator> const_reverse_iterator;
	
	static const size_type npos = ~0;
	
	/*
	 * Constructors and deconstructors:
	 * 	- Empty    constructor
	 * 	- C-String constructor
	 * 	- C-String constructor, with length
	 *  - Copy     constructor
	 * 	- Default  destructor
	 */
	 
	// empty ctor
	basic_string<value_type>() :
		m_Buffer(&m_Null)
	{}
	
	// C-string ctor
	basic_string<value_type>(const value_type* copy) :
		m_Buffer(0)
	{
		size_type len = static_cast<size_type>(strlen(copy));
		construct(len, len);
		memcpy(begin(), copy, length());
	}
	
	// C-string ctor with length
	basic_string<value_type>(const value_type* copy, size_type len) :
		m_Buffer(0)
	{
		construct(len,len);
		memcpy(begin(), copy, len);
	}
	
	// copy constructor
	basic_string<value_type>(const basic_string<value_type>& copy) :
		m_Buffer(0)
	{
		construct(
			copy.length(),
			copy.length()
		);
		memcpy(begin(), copy.c_str(), length());
	}
	
	// destructor
	~basic_string<value_type>()
	{
		if (m_Buffer != &m_Null)
			delete [] (reinterpret_cast<alloc_type*>(m_Buffer));
	}
	
	/*
	 * Methods:
	 * 	- c_str     returns null-terminated C-string
	 *  - data      returns null-terminated C-string
	 *  - length    returns the length of the string
	 *  - size      an alias for length() 
	 *  - empty     returns true on empty string
	 *  - capacity  returns maximum string capacity
	 *  - at        returns a char at index in array
	 *  - reserve   reserves data for string
	 *  - assign    assign string into *this
	 *  - append    append string into *this
	 *  - swap      swap contents with another basic_string<value_type>
	 *  - clear     clear *this string contents
	 *  - resize    resize string
	 *  - push_back append char to string
	 *  - substr    get substring 
	 */
	const value_type* c_str   () const { return m_Buffer->m_Data;                 }
	const value_type* data    () const { return m_Buffer->m_Data;                 }
	size_type         length  () const { return m_Buffer->m_Size;                 }
	size_type         capacity() const { return m_Buffer->m_Caps;                 }
	size_type         size    () const { return m_Buffer->m_Size;                 }
	bool              empty   () const { return m_Buffer->m_Size == 0;            }
	size_type         max_size() const { return numeric_limits<size_type>::max(); }
	
	
	const value_type& at(size_type index) const
	{
		if (index > length())
			throw out_of_range();
		return m_Buffer->m_Data[index];
	}
	
	const value_type& operator[](size_type index) const 
	{
		return m_Buffer->m_Data[index];
	}
	
	// non-const aliases
	value_type& operator[](size_type index) { return operator[](index); }
	value_type& at        (size_type index) { return at        (index); }
	
	void reserve(size_type caps = 0)
	{
		if (caps > capacity())
		{
			basic_string<value_type> tmp;
			tmp.construct(length(), caps);
			memcpy(tmp.begin(), data(), length());
			swap(tmp);
		}
	}
	
	basic_string<value_type>& assign(const value_type* str, size_type len)
	{
		size_type caps = capacity();
		if (len < caps || caps > 3 * (len + 8))
		{
			basic_string<value_type> tmp;
			tmp.construct(len, len);
			memcpy(tmp.begin(), str, len);
			swap(tmp);
		}
		else
		{
			memmove(begin(), str, len);
			m_Buffer->m_Data[m_Buffer->m_Size = len] = '\0';
		}
		return *this;
	}
	
	basic_string<value_type>& append(const value_type* str, size_type len)
	{
		size_type size = length() + len;
		if (size > capacity())
			reserve(size + capacity());
		memmove(end(), str, len);
		m_Buffer->m_Data[m_Buffer->m_Size = size] = '\0';
		
		return *this;
	}
	
	/*
	 * Swap string with another one, no overhead
	 * involved here, buffer is managed by pointer.
	 */
	void swap(basic_string<value_type>& Other)
	{
		stringBufferData *This = m_Buffer;
		m_Buffer               = Other.m_Buffer;
		Other.m_Buffer         = This;
	}
	
	void clear()
	{
		if (m_Buffer != &m_Null)
			delete [] (reinterpret_cast<alloc_type*>(m_Buffer));
		construct(0,0);
	}
	
	void resize(size_t size, char c)
	{
		size_type old = capacity();
		if (size > capacity())
		{
			reserve(size);
			for (size_type i = old; i < size; i++)
				m_Buffer->m_Data[i] = c;
		}
		
		m_Buffer->m_Data[size] = '\0';
		m_Buffer->m_Size       = size;
		m_Buffer->m_Caps       = size;
	}
	
	/*
	 * Alias to resize(), using '\0'
	 * to fill remaining data.
	 */
	void resize(size_t size) {
		resize(size, '\0');
	}
	
	void push_back(char c) {
		append(&c, 1);
	}
	
	
	/*
	 * Assignment operators:
	 * 	- C-String assignment
	 * 	- Copy     assignment
	 *  - C-String append
	 *  - C-Char   append
	 * 	- Copy     append
	 */
	basic_string<value_type>& operator=(const value_type* copy) {
		return assign(copy, static_cast<size_type>(strlen(copy)));
	}
	basic_string<value_type>& operator=(const basic_string<value_type>& copy) {
		return assign(copy.begin(), copy.length());
	}
	basic_string<value_type>& operator+=(const value_type* copy) {
		return append(copy, static_cast<size_type>(strlen(copy)));
	}
	basic_string<value_type>& operator+=(char data) {
		return append(&data, 1);
	}
	basic_string<value_type>& operator+=(const basic_string<value_type>& copy) {
		return append(copy.data(), copy.length());
	}
	
	/*
	 * Iterators
	 */
	const_iterator         begin () const { return m_Buffer->m_Data;                    }
	      iterator         begin ()       { return m_Buffer->m_Data;                    }
	const_iterator         end   () const { return m_Buffer->m_Data + m_Buffer->m_Size; }
	      iterator         end   ()       { return m_Buffer->m_Data + m_Buffer->m_Size; }
	const_reverse_iterator rbegin() const { return const_reverse_iterator(end());       }
	      reverse_iterator rbegin()       { return reverse_iterator(end());             }
	const_reverse_iterator rend  () const { return const_reverse_iterator(begin());     }
	      reverse_iterator rend  ()       { return reverse_iterator(begin());           }
	
private:
	/*
	 * Allocate in allignment, this is fast.
	 */
	void construct(size_type size, size_type caps)
	{
		if (!caps)
			m_Buffer = &m_Null;
		else
		{	
			m_Buffer = reinterpret_cast<stringBufferData*>(
				new alloc_type[((sizeof(stringBufferData) + caps) + sizeof(alloc_type) - 1) / sizeof(alloc_type)]
			);
			
			m_Buffer->m_Data[m_Buffer->m_Size = size] = '\0';
			m_Buffer->m_Caps = caps;
		}
	}
	
	/*
	 * Data structure, this makes
	 * string refrencing simple.
	 */
	struct stringBufferData {
		size_type  m_Size;
		size_type  m_Caps;
		value_type m_Data[1];
	};
	
	stringBufferData  m_Null;
	stringBufferData *m_Buffer;
};

typedef basic_string<char> string;
_ESTL_CLOSE_NAMESPACE

/*
 * Global operators to make life better
 */
inline bool operator == (const estl::string& a, const estl::string& b) {
	return (a.length() == b.length()) && (strcmp(a.c_str(), b.c_str()) == 0);
}
inline bool operator < (const estl::string& a, const estl::string& b) {
	return strcmp(a.c_str(), b.c_str()) < 0;
}

inline bool operator !=(const estl::string             &a, const estl::string             &b) { return !(a == b);                 }
inline bool operator > (const estl::string             &a, const estl::string             &b) { return   b <  a ;                 }
inline bool operator <=(const estl::string             &a, const estl::string             &b) { return !(b <  a);                 }
inline bool operator >=(const estl::string             &a, const estl::string             &b) { return !(a <  b);                 }
inline bool operator ==(const estl::string             &a, const estl::string::value_type *b) { return strcmp(a.c_str(), b) == 0; }
inline bool operator ==(const estl::string::value_type *a, const estl::string             &b) { return   b == a;                  }
inline bool operator !=(const estl::string             &a, const estl::string::value_type *b) { return !(a == b);                 }
inline bool operator !=(const estl::string::value_type *a, const estl::string             &b) { return !(b == a);                 }

#endif
