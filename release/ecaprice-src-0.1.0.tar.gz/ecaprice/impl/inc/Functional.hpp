/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_FUNCTIONAL_HDR
#define ESTL_FUNCTIONAL_HDR
_ESTL_BEGIN_NAMESPACE

// { pre:d } A,R,P
// { pre:d } A1,A2
// { pre:d } unary_function,binary_function
// { pre:d } argument_type,result_type
// { pre:d } first_argument_type,second_argument_type
// { pre:d } unary_negate,binary_negate
// { pre:d } binder1st,binder2nd
// { pre:d } pointer_to_unary_function,pointer_to_binary_function
// { pre:d } not1,not2,plus,minus,multiplies,divides,modulus
// { pre:d } ptr_fun, bind1st, bind2nd
// { pre:d } mem_fun_t,mem_fun1_t,const_mem_fun_t,const_mem_fun1_t
// { pre:d } mem_fun_ref_t,mem_fun1_ref_t,const_mem_fun_ref_t,const_mem_fun1_ref_t
// { pre:d } equal_to,not_equal_to,greater,less,greater_equal,less_equal
// { pre:d } logical_and,logical_or,logical_not

template<typename A, typename R>
struct unary_function 
{ 
    typedef A argument_type;
    typedef R   result_type;
};
template<typename A1, typename A2, typename R>
struct binary_function 
{
    typedef A1 first_argument_type;
    typedef A2 second_argument_type;
    typedef R  result_type;
};

// Generates a function object class that negates the behavior of an 
// unary function object class.
template<typename P>
class unary_negate : public unary_function<typename P::argument_type, bool>
{
protected:
    P fn;
public:
    explicit unary_negate(const P& p) :
        fn(p)
    {}

    bool operator()(const typename P::argument_type& x) const {
        return !fn(x);
    }
};

// Generates a function object class that negates the behavior of an
// binary function object class.
template<typename P>
class binary_negate : public binary_function<typename P::first_argument_type,
                                             typename P::second_argument_type, bool>
{
protected:
    P fn;
public:
    explicit binary_negate(const P& p) :
        fn(p)
    {}

    bool operator()(const typename P::first_argument_type & x,
                    const typename P::second_argument_type& y) const {
        return !fn(x,y);
    }
};

// Generates an unary function object class from the binary object class
// Operation by binding its first parameter to a fixed value.
template<typename O> 
class binder1st : public unary_function<typename O::second_argument_type,
                                        typename O::result_type>
{
protected:
    O op;
    typename O::first_argument_type value;
public:
    binder1st(const O& x, const typename O::first_argument_type& y) :
        op   (x),
        value(y)
    {}

    typename O::result_type operator()
    (const typename O::second_argument_type& x) const {
        return op(value, x);
    }
};

// Generates an unary function object class from the binary object class O
// by binding its second parameter to a fixed value.
template<typename O>
class binder2nd : public unary_function<typename O::first_argument_type,
                                        typename O::result_type>
{
protected:
    O op;
    typename O::second_argument_type value;
public:
    binder2nd(const O& x, const typename O::second_argument_type& y) :
        op   (x),
        value(y)
    {}

    typename O::result_type operator()
    (const typename O::first_argument_type& x) const {
        return op(x, value);
    }
};

// Generates an unary function object class from a pointer to a function 
// that takes a single argument of type A and returns a value of type R.
template<typename A, typename R>
class pointer_to_unary_function : public unary_function<A,R>
{
protected:
    R(*pfunc)(A);
public:
    explicit pointer_to_unary_function(R (*f)(A)) :
        pfunc(f)
    {}
    R operator ()(A x) const { return pfunc(x); }
};

// Generates a binary function object class from a pointer to a function 
// that takes two arguments (of type A1 and A2) and returns a value 
// (of type R).
template<typename A1, typename A2, typename R>
class pointer_to_binary_function : public binary_function<A1,A2,R>
{ 
protected:
    R(*pfunc)(A1,A2);
public:
    explicit pointer_to_binary_function(R (*f)(A1,A2)) :
        pfunc(f)
    {}
    R operator ()(A1 x, A2 y) const { return pfunc(x,y); }
};

// Generates an unary function object class from a parameterless member
// of class T that returns a value of type S.
template<typename S, typename T>
class mem_fun_t : public unary_function<T*, S>
{
    S (T::*pmem)();
public:
    explicit mem_fun_t(S (T::*p)()) : pmem(p) {}

    S operator()(T* p) const {
        return (p->*pmem)();
    }
};

// Generates a binary function object class from a member of class T
// that takes an argument of type A and returns a value of type S.
template<typename S, typename T, typename A>
class mem_fun1_t : public binary_function<T*,A,S>
{
    S (T::*pmem)(A);
public:
    explicit mem_fun1_t(S (T::*p)(A)) : pmem(p) {}

    S operator()(T* p, A x) const {
        return (p->*pmem)(x);
    }
};

// Generates an unary function object class from a constant parameterless
// member of class T that returns a value of type S.
template<typename S, typename T>
class const_mem_fun_t : public unary_function<T*,S>
{
    S (T::*pmem)() const;
public:
    explicit const_mem_fun_t(S (T::*p)() const) : pmem(p) {}

    S operator()(T* p) const {
        return (p->*pmem)(); 
    }
};

// Generates a binary function object class from a constant member of 
// class T that takes an argument of type A and returns a value of type S.
template<typename S, typename T, typename A>
class const_mem_fun1_t : public binary_function<T*,A,S>
{
    S (T::*pmem)(A) const;
public:
    explicit const_mem_fun1_t(S (T::*p)(A) const) : pmem(p) {}

    S operator()(T* p, A x) const {
        return (p->*pmem)(x);
    }
};

// Generates an unary function object class from a parameterless member 
// of class T that returns a value of type S.
template<typename S, typename T>
class mem_fun_ref_t : public unary_function<T,S>
{
    S (T::*pmem)();
public:
    explicit mem_fun_ref_t(S (T::*p)()) : pmem(p) {}

    S operator()(T& p) const {
        return (p.*pmem)();
    }
};

// Generates a binary function object class from a member of class T 
// that takes an argument of type A and returns a value of type S.
template<typename S, typename T, typename A>
class mem_fun1_ref_t : public binary_function<T,A,S>
{
    S (T::*pmem)(A);
public:
    explicit mem_fun1_ref_t(S (T::*p)(A)) : pmem(p) {}

    S operator()(T& p, A x) const {
        return (p.*pmem)(x);
    }
};

// Generates an unary function object class from a constant parameterless
// member of class T that returns a value of type S.
template<typename S, typename T>
class const_mem_fun_ref_t : public unary_function<T,S>
{
    S (T::*pmem)() const;
public:
    explicit const_mem_fun_ref_t(S (T::*p)() const) : pmem(p) {}

    S operator()(T& p) const {
        return (p.*pmem)();
    }
};

// Generates a binary function object class from a constant member of 
// class T that takes an argument of type A and returns a value of type S.
template<typename S, typename T, typename A>
class const_mem_fun1_ref_t : public binary_function<T,A,S>
{
    S (T::*pmem)(A) const;
public:
    explicit const_mem_fun1_ref_t(S (T::*p)(A) const) : pmem(p) {}

    S operator()(T& p, A x) const {
        return (p.*pmem)(x);
    }
};

/**
 * Arithmetic operations
 **/
//binary
template<typename T> struct plus       : binary_function<T,T,T> {
    T operator()(const T& x, const T& y) const { return x+y; }};
template<typename T> struct minus      : binary_function<T,T,T> {
    T operator()(const T& x, const T& y) const { return x-y; }};
template<typename T> struct multiplies : binary_function<T,T,T> {
    T operator()(const T& x, const T& y) const { return x*y; }};
template<typename T> struct divides    : binary_function<T,T,T> {
    T operator()(const T& x, const T& y) const { return x/y; }};
template<typename T> struct modulus    : binary_function<T,T,T> {
    T operator()(const T& x, const T& y) const { return x%y; }};
//unary
template<typename T> struct negate : unary_function <T,T> {
    T operator()(const T& x) const { return -x; }
};
/**
 * Comparison operations
 **/
//binary
template<typename T> struct equal_to       : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x==y; }};
template<typename T> struct not_equal_to   : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x!=y; }};
template<typename T> struct greater        : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x >y; }};
template<typename T> struct less           : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x <y; }};
template<typename T> struct greater_equal  : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x>=y; }};
template<typename T> struct less_equal     : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x<=y; }};
/**
 * Logical operations
 **/
//binary
template<typename T> struct logical_and : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x&&y; }}; 
template<typename T> struct logical_or  : binary_function<T,T,bool> {
    bool operator()(const T& x, const T& y) const { return x||y; }};
//unary
template<typename T> struct logical_not : unary_function<T,bool> {
    bool operator()(const T& x) const { return !x; }
};

/**
 * Negators
 **/
template<typename P>  // Return negation of unary  function object
unary_negate <P> not1(const P& p) { return unary_negate <P>(p); }
template<typename P>  // Return negation of binary function object
binary_negate<P> not2(const P& p) { return binary_negate<P>(p); }

/**
 * Parameter binders
 **/
template<typename O, typename T>
binder1st<O> bind1st(const O& op, const T& x) {
    return binder1st<O>(op, typename  O::first_argument_type(x));}
template<typename O, typename T>
binder2nd<O> bind2nd(const O& op, const T& x) {
    return binder2nd<O>(op, typename O::second_argument_type(x));}

/**
 * Conversors
 **/
template<typename A1, typename R>
pointer_to_unary_function<A1,R> ptr_fun(R (*f)(A1)) {
    return pointer_to_unary_function<A1,R>(f);}
template<typename A1, typename A2, typename R>
pointer_to_binary_function<A1,A2,R> ptr_fun(R (*f)(A1, A2)) {
    return pointer_to_binary_function<A1,A2,R>(f);}

/** mem_fun helper **/
template<typename S,typename T>                  mem_fun_t     <S,T>   mem_fun    (S (T::*f)( ) /***/) { return       mem_fun_t     <S,T>  (f); }
template<typename S,typename T,typename A>       mem_fun1_t    <S,T,A> mem_fun    (S (T::*f)(A) /***/) { return       mem_fun1_t    <S,T,A>(f); }
template<typename S,typename T>            const_mem_fun_t     <S,T>   mem_fun    (S (T::*f)( ) const) { return const_mem_fun_t     <S,T>  (f); }
template<typename S,typename T,typename A> const_mem_fun1_t    <S,T,A> mem_fun    (S (T::*f)(A) const) { return const_mem_fun1_t    <S,T,A>(f); }
template<typename S,typename T>                  mem_fun_ref_t <S,T>   mem_fun_ref(S (T::*f)( ) /***/) { return       mem_fun_ref_t <S,T>  (f); }
template<typename S,typename T,typename A>       mem_fun1_ref_t<S,T,A> mem_fun_ref(S (T::*f)(A) /***/) { return       mem_fun1_ref_t<S,T,A>(f); }
template<typename S,typename T>            const_mem_fun_ref_t <S,T>   mem_fun_ref(S (T::*f)( ) const) { return const_mem_fun_ref_t <S,T>  (f); }
template<typename S,typename T,typename A> const_mem_fun1_ref_t<S,T,A> mem_fun_ref(S (T::*f)(A) const) { return const_mem_fun1_ref_t<S,T,A>(f); }

_ESTL_CLOSE_NAMESPACE

#endif
