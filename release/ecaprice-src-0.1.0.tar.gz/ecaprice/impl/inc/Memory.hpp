/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_MEMORY_HDR
#define ESTL_MEMORY_HDR
#include "Iterator.hpp"
#include "Pair.hpp"
_ESTL_BEGIN_NAMESPACE
// { pre:d } auto_ptr,value_type,pointer,refrence,get,release,reset

template<typename T>
class auto_ptr
{
public:
    typedef T                 value_type;
    typedef value_type*       pointer;
    typedef value_type&       reference;
    typedef const value_type* const_pointer;

    /** Constructors **/
    inline explicit auto_ptr (pointer      p = 0) : m_p (p          ) {}
    inline          auto_ptr (auto_ptr<T>& p    ) : m_p (p.release()) {}

    /** Destructor(s) **/
    inline ~auto_ptr   () { delete m_p ; }


    /** Member Methods **/
    inline pointer get     () const { return (m_p); }
    inline pointer release ()
    {
        pointer rv (m_p);
        m_p = 0;
        return (rv);
    }

    inline void reset(pointer p)
    {
        if(p != m_p)
        {
            delete m_p;
                   m_p = p;
        }
    }
    
    /** Operators **/
    inline auto_ptr<T>& operator= (pointer      p) { reset (p          ); return (*this); }
    inline auto_ptr<T>& operator= (auto_ptr<T>& p) { reset (p.release()); return (*this); }

    inline reference operator* () const { return (*m_p); }
    inline pointer   operator->() const { return ( m_p); }

    inline bool operator== (const_pointer      p) const { return (m_p == p    ); }
    inline bool operator== (const auto_ptr<T>& p) const { return (m_p == p.m_p); }
    inline bool operator < (const auto_ptr<T>& p) const { return (p.m_p <  m_p); }

private:
    pointer m_p;
};

template<typename C, typename T>
class raw_storage_iterator
{
public:
	explicit raw_storage_iterator(C x) :
		m_Iterator(x)
	{}
	
	raw_storage_iterator<C,T>& operator=(const T& e)
	{
		// placement new
		new (static_cast<void*>(&*m_Iterator)) T (e);
		return *this;
	}
	
	raw_storage_iterator<C,T>& operator++()
	{
		++m_Iterator;
		return *this;
	}
	
	raw_storage_iterator<C,T>& operator++(int)
	{
		raw_storage_iterator<C,T> temp(m_Iterator);
		++m_Iterator;
		return temp;
	}
	
	raw_storage_iterator<C,T>& operator*() { return *this; }
	
protected:
	C m_Iterator;
};

// SPECIALIZED ALGORITHMS
// uninitialized_copy
template<typename I, typename F>
F uninitialized_copy(I first, I last, F result)
{
	for(; first!=last; ++result, ++first)
		new (static_cast<void*>(&*result))
			typename iterator_traits<F>::value_type(*first);
	return result;
}

// uninitialized_fill
template<typename F, typename T>
void uninitialized_fill(F first, F last, const T& filldata)
{
	for(; first!=last; ++first)
		new (static_cast<void*>(&*first))
			typename iterator_traits<F>::value_type(filldata);
}

// uninitialized_fill_n
template<typename F, typename S, typename T>
void uninitialized_fill_n(F first, S n, const T& filldata)
{
	for(; n--; ++first)
		new (static_cast<void*>(&*first))
			typename iterator_traits<F>::value_type(filldata);
}

/* shared and weak ptr impls */
#ifndef ESTL_CXX_OHX
namespace tr1 {
#endif
template<typename T> class weak_ptr;
template<typename T>
class shared_ptr
{
public:
	typedef T                 value_type;
	typedef value_type*       pointer;
	typedef const value_type* const_pointer;
	typedef value_type&       refrence;
	typedef const value_type& const_refrence;
	typedef size_t            size_type;
	
	// ctors
	shared_ptr() :
		m_Ptr  (0),
		m_Count(nil()){
		incref();
	}
	shared_ptr(const shared_ptr<T>& rhs) :
		m_Ptr  (rhs.m_Ptr),
		m_Count(rhs.m_Count){
		incref();
	}
	shared_ptr(pointer ptr) :
		m_Ptr  (ptr),
		m_Count(new size_type(1))
	{}
	explicit shared_ptr(const weak_ptr<T>& wptr) :
		m_Ptr  (wptr.m_Ptr),
		m_Count(wptr.m_Count){
		incref();
	}
	// dtor
	~shared_ptr() { decref(); }
	
	// member operators
	pointer        get()              { return  m_Ptr; }
	pointer        operator->()       { return  m_Ptr; }
	refrence       operator* ()       { return *m_Ptr; }
	const_pointer  get()        const { return  m_Ptr; }
	const_pointer  operator->() const { return  m_Ptr; }
	const_refrence operator* () const { return *m_Ptr; }
	
	bool operator==(const shared_ptr<value_type>& c) const { return m_Ptr == c.m_Ptr; }
	bool operator!=(const shared_ptr<value_type>& c) const { return m_Ptr != c.m_Ptr; }
	bool operator< (const shared_ptr<value_type>& c) const { return m_Ptr <  c.m_Ptr; }
	
	size_type refcount() const {
		return *m_Count;
	}	
	
private:
	pointer    m_Ptr;
	size_type* m_Count;
	
	static size_type* nil() {
		static size_type nil_counter = 1;
		return &nil_counter;
	}
	
	void decref()
	{
		if(--(*m_Count) == 0)
		{
			delete m_Ptr;
			delete m_Count;
		}
	}
	void incref()
	{
		++(*m_Count);
	}
};

template<typename T>
class weak_ptr
{
public:
	typedef T                 value_type;
	typedef value_type*       pointer;
	typedef const value_type* const_pointer;
	typedef value_type&       refrence;
	typedef const value_type& const_refrence;
	typedef size_t            size_type;
	
	// ctors
	weak_ptr() :
		m_Ptr  (0),
		m_Count(shared_ptr<value_type>::nil())
	{}
	explicit weak_ptr(const shared_ptr<value_type>& s) :
		m_Ptr  (s.m_Ptr),
		m_Count(s.m_Count)
	{}
	
	shared_ptr<value_type> lock() const {
		return shared_ptr<value_type>(*this);
	}
	
	// member operators
	pointer        get()              { return  m_Ptr; }
	pointer        operator->()       { return  m_Ptr; }
	refrence       operator* ()       { return *m_Ptr; }
	const_pointer  get()        const { return  m_Ptr; }
	const_pointer  operator->() const { return  m_Ptr; }
	const_refrence operator* () const { return *m_Ptr; }
	
	bool operator==(const shared_ptr<value_type>& c) const { return m_Ptr == c.m_Ptr; }
	bool operator!=(const shared_ptr<value_type>& c) const { return m_Ptr != c.m_Ptr; }
	bool operator< (const shared_ptr<value_type>& c) const { return m_Ptr <  c.m_Ptr; }
	
	size_type refcount() const {
		return *m_Count;
	}
	
private:
	pointer    m_Ptr;
	size_type* m_Count;
	
	friend class shared_ptr<value_type>;
};

#ifndef ESTL_CXX_OHX
}
#endif

_ESTL_CLOSE_NAMESPACE
#endif
