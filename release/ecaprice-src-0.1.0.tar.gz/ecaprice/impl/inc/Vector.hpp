/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_VECTOR_HDR
#define ESTL_VECTOR_HDR
#include "Common.hpp"
#include "Iterator.hpp"
#include "Algorithm.hpp"
_ESTL_BEGIN_NAMESPACE
// { pre:d } T,I1,I2,vector,MAX_VLENGTH

template<typename T>
class vector
{
public:
	typedef T                                      value_type;
	typedef value_type*                            pointer;
	typedef const value_type*                      const_pointer;
	typedef value_type&                            reference;
	typedef const value_type&                      const_reference;
	typedef pointer                                iterator;
	typedef const_pointer                          const_iterator;
	typedef size_t                                 size_type;
	typedef estl::reverse_iterator<iterator>       reverse_iterator;
	typedef estl::reverse_iterator<const_iterator> const_reverse_iterator;
	
	/// Member functions
	// ctors
	vector() :
		m_Data(0),
		m_Size(0),
		m_Caps(0)
	{}
	explicit vector(size_type sz) :
		m_Data(0),
		m_Size(0),
		m_Caps(0)
	{
		m_Data = new value_type[sz];
	}
	vector(size_type sz, const_reference vs) :
		m_Data(0),
		m_Size(0),
		m_Caps(0)
	{
		m_Size = sz;
		m_Caps = sz;
		m_Data = new value_type[sz];
		for(size_type i = 0; i < m_Size; i++)
			m_Data[i] = vs;
			
	}
	explicit vector(const vector<value_type>& rhs) :
		m_Size(rhs.m_Size),
		m_Caps(rhs.m_Caps)
	{
		if (*this == rhs)
			return;
		
		delete [] m_Data;
		m_Data = new value_type[m_Size];
		memcpy(m_Data, rhs.m_Data, m_Size * sizeof(value_type));
	}
	// dtor
	~vector() {
		clear();
	}
	
	// copy constructor
	vector<value_type>& operator =(const vector<value_type>& rhs) 
	{
		if(*this == rhs)
			return;
			
		delete [] m_Data;
		m_Size = rhs.m_Size;
		m_Caps = rhs.m_Caps;
		m_Data = new value_type[m_Size];
		memcpy(m_Data, rhs.m_Data, m_Size * sizeof(value_type));
	}
	
	/// Iterators
	// forward iterators
	iterator               begin ()       { return m_Data; }
	const_iterator         begin () const { return m_Data; }
	iterator               end   ()       { return m_Data + size(); }
	const_iterator         end   () const { return m_Data + size(); }
	
	// reverse iterators
	reverse_iterator       rbegin()       { return reverse_iterator      (end());   }
	const_reverse_iterator rbegin() const { return const_reverse_iterator(end());   }
	reverse_iterator       rend  ()       { return reverse_iterator      (begin()); }
	const_reverse_iterator rend  () const { return const_reverse_iterator(begin()); }
	
	/// Capacity
	size_type size    () const { return m_Size     ; }
	size_type max_size() const { return MAX_VLENGTH; }
	size_type capacity() const { return m_Caps     ; }
	bool      empty   () const { return m_Size == 0; }
	
	// reserve / resize
	void reserve(size_type c)
	{
		if(m_Data == 0)
		{
			m_Size = 0;
			m_Caps = 0;
		}
		
		pointer buffer = new value_type[c];
		estl::copy(buffer, buffer + m_Size, m_Data);
		m_Caps = c;
		delete [] m_Data;
		m_Data = buffer;
	}
	void resize(size_type sz)
	{
		reserve(sz);
		m_Size =sz ;
	}
	
	/// Element access
	reference       operator[](size_type n)       { return m_Data[n]; }
	const_reference operator[](size_type n) const { return m_Data[n]; }
	reference       at        (size_type n)       { return m_Data[n]; }
	const_reference at        (size_type n) const { return m_Data[n]; }
	
	// iterator like accessing, but refrenced to allow modifications
	reference       front()       { return m_Data[0]; }
	const_reference front() const { return m_Data[0]; }
	reference       back ()       { return m_Data[m_Size-1]; }
	const_reference back () const { return m_Data[m_Size-1]; }
	
	/// Modifiers
	void push_back(const_reference val)
	{
		if(m_Size >= m_Caps)
			reserve(m_Caps + 5);
		m_Data[m_Size++] = val;
	}
	void clear()
	{
		delete [] m_Data;
		m_Size = 0;
		m_Caps = 0;
	}
    void assign(const_iterator i1, const_iterator i2)
    {
		resize(estl::distance(i1,i2));
		estl::copy(i1, i2, begin());
	}
	void assign(size_type n, const_reference v)
	{
		resize(n);
		estl::fill(begin(), end(), v);
	}
    void pop_back() {
		m_Size --;
	}
    // TODO:
    // iterator insert(iterator, refrence);
    // void insert(iterator, size_type, refrence);
    // template<typename I>
    // void insert(iterator, I, I);
    //
    // iterator erase(iterator);
    // iterator erase(iterator, iterator);
    //
    // void swap(vector<T>&);
    
private:
	enum {
		MAX_VLENGTH = 1073741823
	};

	// member data
	pointer    m_Data;
	size_type  m_Size;
	size_type  m_Caps;
};

_ESTL_CLOSE_NAMESPACE
#endif
