/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_ITERATOR_HDR
#define ESTL_ITERATOR_HDR
#include "Common.hpp"
_ESTL_BEGIN_NAMESPACE

/** Prevent macro molestation: util/preprocess.cpp for refrence **/
// { pre:d } C,T,D,P,R
// { pre:d } input_iterator_tag
// { pre:d } output_iterator_tag
// { pre:d } forward_iterator_tag
// { pre:d } bidirectional_iterator_tag
// { pre:d } random_access_iterator_tag
// { pre:d } iterator_traits

template <
    typename C,
    typename T,
    typename D = ptrdiff_t,
    typename P = T*,
    typename R = T& >  
struct iterator
{
    typedef T value_type;
    typedef D difference_type;
    typedef P pointer;
    typedef R reference;
    typedef C iterator_category;
};

// iterator tags
struct input_iterator_tag         { enum { value = 1 }; };
struct output_iterator_tag        { enum { value = 2 }; };
struct forward_iterator_tag       { enum { value = 3 }; };
struct bidirectional_iterator_tag { enum { value = 4 }; };
struct random_access_iterator_tag { enum { value = 5 }; }; 

template<typename I>
struct iterator_traits
{
    typedef typename I::difference_type   difference_type;
    typedef typename I::value_type        value_type;
    typedef typename I::pointer           pointer;
    typedef typename I::reference         reference;
    typedef typename I::iterator_category iterator_category;
};

// template specialization for pointer and pointer to const
// iterators.
template<typename T>
struct iterator_traits<T*>
{
    typedef ptrdiff_t                  difference_type;
    typedef T                          value_type;
    typedef T*                         pointer;
    typedef const T*                   const_pointer;
    typedef T&                         reference;
    typedef const T&                   const_refrence;
    typedef random_access_iterator_tag iterator_category;
};
template<typename T>
struct iterator_traits<const T*>
{
    typedef ptrdiff_t                  difference_type;
    typedef T                          value_type;
    typedef const T*                   pointer;
    typedef const T*                   const_pointer;
    typedef const T&                   reference;
    typedef const T&                   const_refrence;
    typedef random_access_iterator_tag iterator_category;
};
template<>
struct iterator_traits<void *>
{
    typedef ptrdiff_t                  difference_type;
    typedef unsigned char              value_type;
    typedef void*                      pointer;
    typedef const void*                const_pointer;
    typedef value_type&                reference;
    typedef const value_type&          const_refrence;
    typedef random_access_iterator_tag iterator_category;
};
template<>
struct iterator_traits<const void *>
{
    typedef ptrdiff_t                  difference_type;
    typedef unsigned char              value_type;
    typedef const void*                pointer;
    typedef const void*                const_pointer;
    typedef const value_type&          reference;
    typedef const value_type&          const_refrence;
    typedef random_access_iterator_tag iterator_category;
};

/* reverse iterator */
template<typename T>
class reverse_iterator 
{
public:
    typedef typename iterator_traits<T>::value_type      value_type;
    typedef typename iterator_traits<T>::difference_type difference_type;
    typedef typename iterator_traits<T>::pointer         pointer;
    typedef typename iterator_traits<T>::reference       reference;

    // constructors
             reverse_iterator (void) : m_I(  ) {}
    explicit reverse_iterator (T it) : m_I(it) {}

    // access base
    inline T base (void) const { return m_I; }

    inline difference_type   operator-  (const reverse_iterator& iter) const { return distance(m_I,   iter.m_I); }
    inline bool              operator== (const reverse_iterator& iter) const { return         (m_I == iter.m_I); }
    inline bool              operator<  (const reverse_iterator& iter) const { return         (m_I >  iter.m_I); }

    inline reverse_iterator& operator+= (size_t n) { m_I -= n; return (*this); }
    inline reverse_iterator& operator-= (size_t n) { m_I += n; return (*this); }

    inline reverse_iterator& operator++ (void) { -- m_I; return (*this); }
    inline reverse_iterator& operator-- (void) { ++ m_I; return (*this); }

    inline reverse_iterator  operator++ (int) { reverse_iterator prev (*this); -- m_I; return (prev); }
    inline reverse_iterator  operator-- (int) { reverse_iterator prev (*this); ++ m_I; return (prev); }

    inline reverse_iterator  operator+  (size_t n) const { return (reverse_iterator (m_I - n)); }
    inline reverse_iterator  operator-  (size_t n) const { return (reverse_iterator (m_I + n)); }

    inline reference         operator[] (size_t nop) const { return (*(*this + nop)); }
    inline pointer           operator-> (void)       const { return (&(operator*())); }

    inline reference operator* (void) const
    {
        T previous(m_I);
        --previous;
        return(*previous);
    }
protected:
    T m_I;
};

/* insert iterator */
template<typename T>
class insert_iterator
{
public:
	typedef typename T::value_type       value_type;
	typedef typename T::difference_type  difference_type;
	typedef typename T::pointer          pointer;
	typedef typename T::reference        reference;
	typedef typename T::iterator         iterator;
	
	explicit insert_iterator(T& c, iterator i) :
		m_C(c),
		m_I(i)
	{}
	
	insert_iterator& operator* (void) {       return *this; }
	insert_iterator& operator++(void) { ++m_I;return *this; }
	insert_iterator  operator++ (int)
	{
		insert_iterator prev(*this);
		++m_I;
		return prev;
	}
	
	insert_iterator& operator= (typename T::const_reference value)
	{
		m_I = m_C.insert(m_I, value);
		return *this;
	}
	
protected:
	T        m_C;
	iterator m_I;
};

// returns insert iterator ctr
template<typename C>
inline insert_iterator<C> inserter (
	typename C::reference ctr,
	typename C::iterator  itr
) {
	return insert_iterator<C>(ctr,itr);
}

_ESTL_CLOSE_NAMESPACE
#endif
