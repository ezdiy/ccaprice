/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_ARRAY_HDR
#define ESTL_ARRAY_HDR
#include "Common.hpp"
#include "Iterator.hpp"
#include "Algorithm.hpp"
// { pre:d } tr1,array,T,N
_ESTL_BEGIN_NAMESPACE
#ifndef ESTL_CXX_OHX
	/*
	 * If C++0x is not enabled, throw it in namespace TR1
	 * a.k.a technical report #1.
	 */
	namespace tr1 {
#endif

	template<typename T, size_t N>
	class array 
	{
	public:
		typedef T                                      value_type;
		typedef T*                                     pointer;
		typedef const T*                               const_pointer;
		typedef value_type*                            iterator;
		typedef const value_type*                      const_iterator;
		typedef value_type&                            reference;
		typedef const value_type&                      const_reference;
		typedef size_t                                 size_type;
		typedef ptrdiff_t                              difference_type;
		typedef estl::reverse_iterator<iterator>       reverse_iterator;
		typedef estl::reverse_iterator<const_iterator> const_reverse_iterator;
			
		/*
		 * Iterators
		 */
		iterator               begin  ()       { return m_Elements;   }
		const_iterator         begin  () const { return m_Elements;   }
		const_iterator         cbegin () const { return m_Elements;   }
		iterator               end    ()       { return m_Elements+N; }
		const_iterator         end    () const { return m_Elements+N; }
		const_iterator         cend   () const { return m_Elements+N; }
		reverse_iterator       rbegin ()       { return reverse_iterator      (end  ()); }
		const_reverse_iterator rbegin () const { return const_reverse_iterator(end  ()); }
		const_reverse_iterator crbegin() const { return const_reverse_iterator(end  ()); }
		reverse_iterator       rend   ()       { return reverse_iterator      (begin()); }
		const_reverse_iterator rend   () const { return const_reverse_iterator(begin()); }
		const_reverse_iterator crend  () const { return const_reverse_iterator(begin()); }
		
		/*
		 * Accessing methods
		 */
		reference       operator[](size_type i)       { return m_Elements[i]; }
		const_reference operator[](size_type i) const { return m_Elements[i]; }
		
		/*
		 * Range checking at method
		 * Returns last element if out of range.
		 */
		reference       at(size_type i)       { return m_Elements[(i<=N)?i:(N-1)]; }
		const_reference at(size_type i) const { return m_Elements[(i<=N)?i:(N-1)]; }
		
		/*
		 * front(), and back() implementation
		 */
		reference       front()       { return m_Elements[0]  ; }
		const_reference front() const { return m_Elements[0]  ; }
		reference       back ()       { return m_Elements[N-1]; }
		const_reference back () const { return m_Elements[N-1]; }
		
		/*
		 * Size is constant, this is not a vector
		 */
		static size_type size    () { return N;     }
		static bool      empty   () { return false; }
		static size_type max_size() { return N;     }
		
		// constant `array<T,N>::static_size`
		enum { static_size = N };
		
		void swap(array<T,N>& data) {
			swap_ranges(data.begin(), data.end(), data, begin());
		}
		
		/*
		 * Direct access to data, as pointer.
		 */
		const value_type* data() const { return m_Elements; } // read only
			  value_type* data()       { return m_Elements; } // read and write
			  
		/*
		 * Type conversion assignment
		 */
		template<typename C>
		array<T,N>& operator=(const array<C,N>& rhs)
		{
			copy(rhs.begin(), rhs.end(), begin());
			return *this;
		}
		
		/*
		 * Assign one value to all elements inside
		 * m_Elements, replicates C style `= {0}`
		 */
		void assign(const_reference value) { fill(value); }
		void fill  (const_reference value) {
			fill_n(begin(),size(),value);
		}
		
	public:
		T m_Elements[N];
	};

#ifndef ESTL_CXX_OHX
	} /* namespace tr1 */
#endif
_ESTL_CLOSE_NAMESPACE /*namespace estl */
#endif
