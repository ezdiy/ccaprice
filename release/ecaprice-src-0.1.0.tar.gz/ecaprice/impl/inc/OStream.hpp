/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_OSTREAM_HDR
#define ESTL_OSTREAM_HDR

#include "Common.hpp"
#include "IOSBase.hpp"
#include "String.hpp"
#include <string.h>

_ESTL_BEGIN_NAMESPACE

// { pre:d } ostream,cout

class ostream : public ios
{
public:
    #define OSTREAM_OUTPUT_OPERATOR(type, code) \
        ostream& operator<<(type f) {           \
            code                                \
            return *this;                       \
    }
    #define OSTREAM_NUMFMT_OPERATOR(type, co)   \
        ostream& operator << (type f) {         \
            char buf[SHRT_MAX];                 \
            snprintf(buf,SHRT_MAX-1,co,f);      \
            fputs(buf, stdout);                 \
            return *this;                       \
        } 

    OSTREAM_OUTPUT_OPERATOR(const char*   , { fputs((char*)f        ,stdout); })
    OSTREAM_OUTPUT_OPERATOR(estl::string  , { fputs((char*)f.c_str(),stdout); })
    OSTREAM_OUTPUT_OPERATOR(const char    , { fputc((int  )f        ,stdout); })
    OSTREAM_OUTPUT_OPERATOR(unsigned char*, { fputs((char*)f        ,stdout); })
    OSTREAM_OUTPUT_OPERATOR(unsigned char , { fputc((int  )f        ,stdout); })
    OSTREAM_NUMFMT_OPERATOR(int              , "%i" )
    OSTREAM_NUMFMT_OPERATOR(float            , "%f" )
    OSTREAM_NUMFMT_OPERATOR(double           , "%f" )
    OSTREAM_NUMFMT_OPERATOR(short            , "%hd")
    OSTREAM_NUMFMT_OPERATOR(long int         , "%li")
    OSTREAM_NUMFMT_OPERATOR(unsigned int     , "%u" )
    OSTREAM_NUMFMT_OPERATOR(long unsigned int, "%lu")

private:
}; ostream cout;

_ESTL_CLOSE_NAMESPACE
#endif
