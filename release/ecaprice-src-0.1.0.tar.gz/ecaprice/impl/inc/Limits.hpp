/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_LIMITS_HDR
#define ESTL_LIMITS_HDR
#include "Common.hpp"
_ESTL_BEGIN_NAMESPACE

enum float_round_style
{
	round_indeterminate       = -1, // rounding style cannot be determined at compile time
	round_toward_zero         =  0, // rounding style toward zero
	round_to_nearest          =  1, // rounding style to the nearest representable value
	round_toward_infinity     =  2, // rounding style toward infinity
	round_toward_neg_infinity =  3  // rounding style toward negitive infinity
};

enum float_denorm_style
{
	denorm_indeterminate      = -1, // denormalization style for the type cannot be determined at compile time
	denorm_absent             =  0, // the type does not allow denormalized values
	denorm_present            =  1  // the type allows denormalized values
};

_ESTL_PRIV_BEGIN(_ESTL_PRIV_GLOBAL)
{
	template<typename T> struct numeric_limits_traps           {enum{value=0};};
	template<typename T> struct numeric_limits_has_denorm_loss {enum{value=0};};
	template<typename T> struct numeric_limits_tinyness_before {enum{value=0};};
	
	// helper function to implement trapping on
	// a user selected type, example of use:
	// ESTL_NUMERIC_LIMITS_TRAP_IMPL(float)
	#define ESTL_NUMERIC_LIMITS_TRAP_IMPL(X) \
		_ESTL_PRIV_BEGIN(_ESTL_PRIV_GLOBAL)  \
		{                                    \
			template<>                       \
			struct numeric_limits_traps<X> { \
				enum { value=1 };            \
			};                               \
		}
	

	template<typename T>
	struct numeric_limits_signed {
		static const bool value = (static_cast<T>(-1) < 0);
	};
	
	template<typename T>
	struct numeric_limits_digits00
	{
		static const T value = (
			sizeof(T) * static_cast<T>(__CHAR_BIT__) -
			numeric_limits_signed<T>::value
		);
	};
	
	template<typename T>
	struct numeric_limits_digits10
	{
		static const T value = (
			numeric_limits_digits00<T>::value * 643/2136
		);
	};
	
	template<typename T>
	struct numeric_limits_min
	{
		static const T value = static_cast<T>(
			(numeric_limits_signed<T>::value)?(                               \
				(( static_cast<T>(1) << numeric_limits_digits00<T>::value)-0) \
			) :  ( static_cast<T>(0))
		);
	};
	
	template<typename T>
	struct numeric_limits_max
	{
		static const T value = static_cast<T>(
			(numeric_limits_signed<T>::value) ?                                           \
				((((static_cast<T>(1 << (numeric_limits_digits00<T>::value-1)))-1)<<1)+1  \
			)     :~static_cast<T>(0)
		);
	};
	
	template<typename T>
	struct numeric_limits_base
	{
		typedef T value_type;
		
		static const bool               is_specialized        = false;
		static const int                digits                = 0;
		static const int                digits10              = 0;
		static const bool               is_signed             = false;
		static const bool               is_integer            = false;
		static const bool               is_exact              = false;
		static const int                radix                 = 0;
		static const int                min_exponent          = 0;
		static const int                min_exponent10        = 0;
		static const int                max_exponent          = 0;
		static const int                max_exponent10        = 0;
		static const bool               has_infinity          = false;
		static const bool               has_quiet_NaN         = false;
		static const bool               has_signaling_NaN     = false;
		static const float_denorm_style has_denorm            = denorm_absent;
		static const bool               has_denorm_loss       = false;
		static const bool               is_iec559             = false;
		static const bool               is_bounded            = false;
		static const bool               is_modulo             = false;
		static const bool               traps                 = false;
		static const bool               tinyness_before       = false;
		static const float_round_style  round_style           = round_toward_zero;
	};
}
// implement the basic traps
ESTL_NUMERIC_LIMITS_TRAP_IMPL(bool)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(char)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(signed char)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(unsigned char)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(wchar_t)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(short)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(unsigned short)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(int)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(unsigned int)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(long)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(unsigned long)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(long long)
ESTL_NUMERIC_LIMITS_TRAP_IMPL(unsigned long long)

template<typename T>
struct numeric_limits : public _ESTL_PRIV_PLACE::numeric_limits_base<T>
{
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<T>::value_type value_type;
	
	static value_type min          () _ESTL_THROW { return static_cast<value_type>(0); }
	static value_type max          () _ESTL_THROW { return static_cast<value_type>(0); }
	static value_type epsilon      () _ESTL_THROW { return static_cast<value_type>(0); }
	static value_type round_error  () _ESTL_THROW { return static_cast<value_type>(0); }
	static value_type infinity     () _ESTL_THROW { return static_cast<value_type>(0); }
	static value_type quiet_NaN    () _ESTL_THROW { return static_cast<value_type>(0); }
	static value_type signaling_NaN() _ESTL_THROW { return static_cast<value_type>(0); }
	static value_type denorm_min   () _ESTL_THROW { return static_cast<value_type>(0); }
};

template<>
struct numeric_limits<bool>
{
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<bool>::value_type value_type;
	
	static bool min          () _ESTL_THROW { return false; }
	static bool max          () _ESTL_THROW { return true ; }	
	static bool epsilon      () _ESTL_THROW { return false; }
	static bool round_error  () _ESTL_THROW { return false; }
	static bool infinity     () _ESTL_THROW { return false; }
	static bool quiet_NaN    () _ESTL_THROW { return false; }
	static bool signaling_NaN() _ESTL_THROW { return false; }
	static bool denorm_min   () _ESTL_THROW { return false; }

	static const bool                is_specialized    = true;
	static const int                 digits            = 1;
	static const int                 digits10          = 0;
	static const bool                is_signed         = false;
	static const bool                is_integer        = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = false;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const bool                has_denorm_loss   = _ESTL_PRIV_PLACE::numeric_limits_has_denorm_loss<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps          <value_type>::value;
};

template<>
struct numeric_limits<char>
{
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<char>::value_type value_type;
	
	static value_type min          () _ESTL_THROW { return value_type(); }
	static value_type max          () _ESTL_THROW { return value_type(); }	
	static value_type epsilon      () _ESTL_THROW { return 0           ; }
	static value_type round_error  () _ESTL_THROW { return 0           ; }
	static value_type infinity     () _ESTL_THROW { return value_type(); }
	static value_type quiet_NaN    () _ESTL_THROW { return value_type(); }
	static value_type signaling_NaN() _ESTL_THROW { return value_type(); }
	static value_type denorm_min   () _ESTL_THROW { return 0           ; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                is_signed         = _ESTL_PRIV_PLACE::numeric_limits_signed  <value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<signed char>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<signed char>::value_type value_type;
	
	static value_type min          () _ESTL_THROW { return -__SCHAR_MAX__-1; }
	static value_type max          () _ESTL_THROW { return  __SCHAR_MAX__  ; }	
	static value_type epsilon      () _ESTL_THROW { return 0               ; }
	static value_type round_error  () _ESTL_THROW { return 0               ; }
	static value_type infinity     () _ESTL_THROW { return 0               ; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0               ; }
	static value_type signaling_NaN() _ESTL_THROW { return 0               ; }
	static value_type denorm_min   () _ESTL_THROW { return 0               ; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<unsigned char>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<unsigned char>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return __SCHAR_MAX__*2U+1; }
	static value_type min          () _ESTL_THROW { return 0; }	
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = false;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<wchar_t>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<wchar_t>::value_type value_type;
	
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return value_type(); }
	static value_type quiet_NaN    () _ESTL_THROW { return value_type(); }
	static value_type signaling_NaN() _ESTL_THROW { return value_type(); }
	static value_type denorm_min   () _ESTL_THROW { return value_type(); }
	static value_type min          () _ESTL_THROW { return _ESTL_PRIV_PLACE::numeric_limits_min<value_type>::value; }
	static value_type max          () _ESTL_THROW { return _ESTL_PRIV_PLACE::numeric_limits_max<value_type>::value; }	

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
	static const bool                is_signed         = _ESTL_PRIV_PLACE::numeric_limits_signed  <value_type>::value;
};

template<>
struct numeric_limits<short>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<short>::value_type value_type;
	
	static value_type min          () _ESTL_THROW { return -__SHRT_MAX__-1; }
	static value_type max          () _ESTL_THROW { return  __SHRT_MAX__  ; }	
	static value_type epsilon      () _ESTL_THROW { return 0              ; }
	static value_type round_error  () _ESTL_THROW { return 0              ; }
	static value_type infinity     () _ESTL_THROW { return value_type()   ; }
	static value_type quiet_NaN    () _ESTL_THROW { return value_type()   ; }
	static value_type signaling_NaN() _ESTL_THROW { return value_type()   ; }
	static value_type denorm_min   () _ESTL_THROW { return value_type()   ; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<unsigned short>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<unsigned short>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return  __SHRT_MAX__*2U+1; }
	static value_type min          () _ESTL_THROW { return 0; }
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = false;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<int>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<int>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return  __INT_MAX__  ; }
	static value_type min          () _ESTL_THROW { return -__INT_MAX__-1; }
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<unsigned int>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<unsigned int>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return  __INT_MAX__*2U+1; }
	static value_type min          () _ESTL_THROW { return 0; }
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = false;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<long>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<long>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return  __LONG_MAX__  ; }
	static value_type min          () _ESTL_THROW { return -__LONG_MAX__-1; }
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<unsigned long>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<unsigned long>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return  __LONG_MAX__*2UL+1; }
	static value_type min          () _ESTL_THROW { return 0; }
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = false;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<long long>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<long long>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return  __LONG_LONG_MAX__  ; }
	static value_type min          () _ESTL_THROW { return -__LONG_LONG_MAX__-1; }
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = true;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<unsigned long long>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<unsigned long long>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return __LONG_LONG_MAX__*2ULL+1; }
	static value_type min          () _ESTL_THROW { return 0; }
	static value_type epsilon      () _ESTL_THROW { return 0; }
	static value_type round_error  () _ESTL_THROW { return 0; }
	static value_type infinity     () _ESTL_THROW { return 0; }
	static value_type quiet_NaN    () _ESTL_THROW { return 0; }
	static value_type signaling_NaN() _ESTL_THROW { return 0; }
	static value_type denorm_min   () _ESTL_THROW { return 0; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = true;
	static const bool                is_signed         = false;
	static const bool                is_exact          = true;
	static const int                 radix             = 2;
	static const int                 min_exponent      = 0;
	static const int                 min_exponent10    = 0;
	static const int                 max_exponent      = 0;
	static const int                 max_exponent10    = 0;
	static const bool                has_infinity      = false;
	static const bool                has_quiet_NaN     = false;
	static const bool                has_signaling_NaN = false;
	static const float_denorm_style  has_denorm        = denorm_absent;
	static const bool                has_denorm_loss   = false;
	static const bool                is_iec559         = false;
	static const bool                is_bounded        = true ;
	static const bool                is_modulo         = true ;
	static const bool                tinyness_before   = false;
	static const float_round_style   round_style       = round_toward_zero;
	static const int                 digits            = _ESTL_PRIV_PLACE::numeric_limits_digits00<value_type>::value;
	static const int                 digits10          = _ESTL_PRIV_PLACE::numeric_limits_digits10<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps   <value_type>::value;
};

template<>
struct numeric_limits<float>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<float>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return __FLT_MAX__            ; }
	static value_type min          () _ESTL_THROW { return __FLT_MIN__            ; }
	static value_type epsilon      () _ESTL_THROW { return __FLT_EPSILON__        ; }
	static value_type round_error  () _ESTL_THROW { return 0.5F                   ; }
	static value_type infinity     () _ESTL_THROW { return __builtin_huge_valf(  ); }
	static value_type quiet_NaN    () _ESTL_THROW { return __builtin_nanf     (""); }
	static value_type signaling_NaN() _ESTL_THROW { return __builtin_nansf    (""); }
	static value_type denorm_min   () _ESTL_THROW { return __FLT_DENORM_MIN__     ; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = false;
	static const bool                is_signed         = true;
	static const bool                is_exact          = true;
	static const int                 radix             = __FLT_RADIX__;
	static const int                 min_exponent      = __FLT_MIN_EXP__;
	static const int                 min_exponent10    = __FLT_MIN_10_EXP__;
	static const int                 max_exponent      = __FLT_MAX_EXP__;
	static const int                 max_exponent10    = __FLT_MAX_10_EXP__;
	static const bool                has_infinity      = __FLT_HAS_INFINITY__;
	static const bool                has_quiet_NaN     = __FLT_HAS_QUIET_NAN__;
	static const bool                has_signaling_NaN = has_quiet_NaN;
	static const float_denorm_style  has_denorm        = bool(__FLT_HAS_DENORM__)?denorm_present:denorm_absent;
	static const bool                has_denorm_loss   = _ESTL_PRIV_PLACE::numeric_limits_has_denorm_loss<value_type>::value;
	static const bool                is_iec559         = has_infinity && has_quiet_NaN && (has_denorm==denorm_present);
	static const bool                is_bounded        = true;
	static const bool                is_modulo         = false;
	static const bool                tinyness_before   = _ESTL_PRIV_PLACE::numeric_limits_tinyness_before<value_type>::value;
	static const float_round_style   round_style       = round_to_nearest;
	static const int                 digits            = __FLT_MANT_DIG__;
	static const int                 digits10          = __FLT_DIG__;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps<value_type>::value;
};

template<>
struct numeric_limits<double>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<double>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return __DBL_MAX__           ; }
	static value_type min          () _ESTL_THROW { return __DBL_MIN__           ; }
	static value_type epsilon      () _ESTL_THROW { return __DBL_EPSILON__       ; }
	static value_type round_error  () _ESTL_THROW { return 0.5                   ; }
	static value_type infinity     () _ESTL_THROW { return __builtin_huge_val(  ); }
	static value_type quiet_NaN    () _ESTL_THROW { return __builtin_nan     (""); }
	static value_type signaling_NaN() _ESTL_THROW { return __builtin_nans    (""); }
	static value_type denorm_min   () _ESTL_THROW { return __DBL_DENORM_MIN__    ; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = false;
	static const bool                is_signed         = true;
	static const bool                is_exact          = false;
	static const int                 radix             = __FLT_RADIX__;
	static const int                 min_exponent      = __DBL_MIN_EXP__;
	static const int                 min_exponent10    = __DBL_MIN_10_EXP__;
	static const int                 max_exponent      = __DBL_MAX_EXP__;
	static const int                 max_exponent10    = __DBL_MAX_10_EXP__;
	static const bool                has_infinity      = __DBL_HAS_INFINITY__;
	static const bool                has_quiet_NaN     = __DBL_HAS_QUIET_NAN__;
	static const bool                has_signaling_NaN = has_quiet_NaN;
	static const float_denorm_style  has_denorm        = bool(__DBL_HAS_DENORM__) ? denorm_present : denorm_absent;
	static const bool                has_denorm_loss   = _ESTL_PRIV_PLACE::numeric_limits_has_denorm_loss<value_type>::value;
	static const bool                is_iec559         = has_infinity && has_quiet_NaN && (has_denorm == denorm_present);
	static const bool                is_bounded        = true;
	static const bool                is_modulo         = false;
	static const bool                tinyness_before   = _ESTL_PRIV_PLACE::numeric_limits_tinyness_before<value_type>::value;
	static const float_round_style   round_style       = round_to_nearest;
	static const int                 digits            = __DBL_MANT_DIG__;
	static const int                 digits10          = __DBL_DIG__;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps<value_type>::value;
};

template<>
struct numeric_limits<long double>
{	
	typedef typename _ESTL_PRIV_PLACE::numeric_limits_base<long double>::value_type value_type;
	
	static value_type max          () _ESTL_THROW { return __LDBL_MAX__           ; }
	static value_type min          () _ESTL_THROW { return __LDBL_MIN__           ; }
	static value_type epsilon      () _ESTL_THROW { return __LDBL_EPSILON__       ; }
	static value_type round_error  () _ESTL_THROW { return 0.5L                   ; }
	static value_type infinity     () _ESTL_THROW { return __builtin_huge_vall(  ); }
	static value_type quiet_NaN    () _ESTL_THROW { return __builtin_nanl     (""); }
	static value_type signaling_NaN() _ESTL_THROW { return __builtin_nansl    (""); }
	static value_type denorm_min   () _ESTL_THROW { return __LDBL_DENORM_MIN__    ; }

	static const bool                is_specialized    = true;
	static const bool                is_integer        = false;
	static const bool                is_signed         = true;
	static const bool                is_exact          = false;
	static const int                 radix             = __FLT_RADIX__;
	static const int                 min_exponent      = __LDBL_MIN_EXP__;
	static const int                 min_exponent10    = __LDBL_MIN_10_EXP__;
	static const int                 max_exponent      = __LDBL_MAX_EXP__;
	static const int                 max_exponent10    = __LDBL_MAX_10_EXP__;
	static const bool                has_infinity      = __LDBL_HAS_INFINITY__;
	static const bool                has_quiet_NaN     = __LDBL_HAS_QUIET_NAN__;
	static const bool                has_signaling_NaN = has_quiet_NaN;
	static const float_denorm_style  has_denorm        = bool(__LDBL_HAS_DENORM__) ? denorm_present : denorm_absent;
	static const bool                is_iec559         = has_infinity && has_quiet_NaN && (has_denorm == denorm_present);
	static const bool                is_bounded        = true;
	static const bool                is_modulo         = false;
	static const float_round_style   round_style       = round_to_nearest;
	static const int                 digits            = __LDBL_MANT_DIG__;
	static const int                 digits10          = __LDBL_DIG__;
	static const bool                has_denorm_loss   = _ESTL_PRIV_PLACE::numeric_limits_has_denorm_loss<value_type>::value;
	static const bool                tinyness_before   = _ESTL_PRIV_PLACE::numeric_limits_tinyness_before<value_type>::value;
	static const bool                traps             = _ESTL_PRIV_PLACE::numeric_limits_traps          <value_type>::value;
};

_ESTL_CLOSE_NAMESPACE
#endif
