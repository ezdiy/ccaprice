/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_NEW_HDR
#define ESTL_NEW_HDR
#include "Common.hpp"
#include "Limits.hpp"
#include "Exception.hpp"
_ESTL_BEGIN_NAMESPACE

/** Prevent macro molestation: util/preprocess.cpp for refrence **/
// { pre:d } bad_alloc,exception,allocator,allocate,address
// { pre:d } construct,destroy,deallocate,rebind,max_size

class bad_alloc : public exception
{
public:
             bad_alloc() throw();
    virtual ~bad_alloc() throw();

    virtual const char* what() const throw() {
		return "bad allocation";
	}
};

typedef void (*new_handler)();

struct nothrow_t   {};
const  nothrow_t   nothrow  = {};
       new_handler nohandle = {};

inline new_handler set_new_handler(new_handler new_p) _ESTL_NOEXCEPT
{
	static new_handler selfhandle = 0;
	
	nohandle = new_p;
	if (selfhandle == 0)
	{
		selfhandle = new_p;
		return 0;
	}
	return nohandle;
}
	
_ESTL_CLOSE_NAMESPACE

// make global
using estl::nothrow;
using estl::nothrow_t;

inline void* operator new     (size_t n) _ESTL_NOEXCEPT { return malloc(n); }
inline void* operator new[]   (size_t n) _ESTL_NOEXCEPT { return malloc(n); }
inline void  operator delete  (void * p) _ESTL_NOEXCEPT { if(p)  free  (p); }
inline void  operator delete[](void * p) _ESTL_NOEXCEPT { if(p)  free  (p); }

// placement new / delete
inline void* operator new     (size_t, void *p) _ESTL_NOEXCEPT { return (p); }
inline void* operator new[]   (size_t, void *p) _ESTL_NOEXCEPT { return (p); }
inline void  operator delete  (void *, void * ) _ESTL_NOEXCEPT {}
inline void  operator delete[](void *, void * ) _ESTL_NOEXCEPT {}

_ESTL_BEGIN_NAMESPACE

// empty allocator
template<typename T> class allocator;

// void specialization allocator
template<> 
class allocator<void>
{
public:
    typedef void*       pointer;
    typedef const void* const_pointer;
    typedef void        value_type;

    template<typename U>
    struct rebind {
        typedef allocator<U> other;
    };
};

// core allocator implementation
template<typename T>
class allocator
{
public:
    typedef T         value_type;
    typedef T*        pointer;
    typedef T&        refrence;
    typedef const T*  const_pointer;
    typedef const T&  const_refrence;
    typedef size_t    size_type;
    typedef ptrdiff_t difference_type;

    template<typename U>
    struct rebind {
        typedef allocator<U> other;
    };

    // Constructors and Destructors
                         allocator()                    throw() {}
                         allocator(const allocator   &) throw() {}
    template<typename U> allocator(const allocator<U>&) throw() {}
                        ~allocator()                    throw() {}


    // Return address of X
          pointer address(      refrence x) const { return &x; }
    const_pointer address(const_refrence x) const { return &x; }

    
    // Destroys the object of type T pointed by p.
    void destroy(pointer p) {
        ((T*)p)->~T();
    }

    // Constructs an object of type T on the location pointed by p 
    // using its copy constructor to initialize its value to val.
    void construct(pointer p, const_refrence val) {
        ::new((void*)p) T(val);
    }

    // Attempts to allocate a block of storage with a size large enough 
    // to contain n elements of type T, and returns a pointer to the 
    // first element.
    pointer allocate(size_type n, allocator<void>::const_pointer hint=0)
    {
        if(n > this->max_size())
            throw estl::bad_alloc();

        return static_cast<T*>(::operator new(n * sizeof(T)));
    }

    // Releases a block of storage previously allocated with member 
    // allocate and not yet released.
    void deallocate(pointer p, size_type n)
    {
        ::operator delete(p);
    }

    size_type max_size() const {
        return size_t(-1) / sizeof(T);
    }
};

// global == operator overload for allocator comparisment
template<typename T>
inline bool operator ==(const allocator<T>&, const allocator<T>&) { return true;  }
template<typename T>
inline bool operator !=(const allocator<T>&, const allocator<T>&) { return false; }

_ESTL_CLOSE_NAMESPACE
#endif
