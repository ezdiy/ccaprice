/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#ifndef ESTL_HEAP_HDR
#define ESTL_HEAP_HDR
#ifndef ESTL_CXX_OHX
#	warning "<type_traits> is part of C++0x/C++11, you need to #define ESTL_CXX_OHX to use this header"
#endif
#include "Pair.hpp"
_ESTL_BEGIN_NAMESPACE
template<typename T, T v>
struct integral_constant 
{
	/* typedefs */
    typedef T value_type;
    typedef integral_constant<T, v> type;
    
    /* data */
    static constexpr value_type value = v;
    
    /* operators / methods */
    constexpr operator value_type() {
		return value;
	}
};

typedef integral_constant<bool, true>  true_type;
typedef integral_constant<bool, false> false_type;

/** is_* implementations **/
template<typename T> struct is_integral                    : false_type {};
template<typename T> struct is_floating_point              : false_type {};
template<typename T> struct is_pointer                     : false_type {};
template<typename T> struct is_lvalue_reference            : false_type {};
template<typename T> struct is_rvalue_reference            : false_type {};
template<>           struct is_integral<bool>              : true_type  {};
template<>           struct is_integral<char>              : true_type  {};
template<>           struct is_integral<unsigned char>     : true_type  {};
template<>           struct is_integral<signed char>       : true_type  {};
template<>           struct is_integral<short>             : true_type  {};
template<>           struct is_integral<unsigned short>    : true_type  {};
template<>           struct is_integral<int>               : true_type  {};
template<>           struct is_integral<unsigned int>      : true_type  {};
template<>           struct is_integral<long>              : true_type  {};
template<>           struct is_integral<unsigned long>     : true_type  {};
template<>           struct is_floating_point<float>       : true_type  {};
template<>           struct is_floating_point<double>      : true_type  {};
template<>           struct is_floating_point<long double> : true_type  {};
template<typename T> struct is_pointer         <T*>        : true_type  {};
template<typename T> struct is_lvalue_reference<T&>        : true_type  {};
template<typename T> struct is_rvalue_reference<T&&>       : true_type  {};
template<typename T> struct is_pod : integral_constant<bool, (is_integral      <T>::value   ||
                                                              is_floating_point<T>::value   ||
                                                              is_pointer       <T>::value)> {};
template<typename T> struct is_pod<const T> : is_pod<T> {};

/*
 * Conditional expression template:
 * if true  (first ) else
 * if false (second)
 */
template<bool C, typename T1, typename T2> struct conditional              { typedef T1 type; };
template        <typename T1, typename T2> struct conditional<false,T1,T2> { typedef T2 type; };

_ESTL_PRIV_BEGIN(_ESTL_PRIV_GLOBAL)
{
	template<typename...> struct template_and;
	template<typename T1> struct template_and<T1> : public T1 {};
	
	template<typename T1, typename T2>
		struct template_and<T1,T2> : public conditional<T1::value, T2, T1>::type
	{};
	template<typename T1, typename T2, typename T3, typename... T4>
	struct template_and<T1,T2,T3,T4...> :
		public conditional<T1::value, template_and<T1, T3, T4...>, T1>::type
	{};
	
	template<typename...> struct template_or;
	template<typename T1> struct template_or<T1> : public T1 {};
	
	template<typename T1, typename T2>
		struct template_or<T1,T2> : public conditional<T1::value, T1, T2>::type
	{};
	template<typename T1, typename T2, typename T3, typename... T4>
	struct template_or<T1,T2,T3,T4...> :
		public conditional<T1::value, template_or<T2, T3, T4...>, T1>::type
	{};
}

/// enable_if
template<bool, typename T = void> struct enable_if          { /* enable if */ };
template</***/ typename T>        struct enable_if<true, T> { typedef T type; };

/// is_void
template<typename T> struct is_void       : public false_type {};
template<>           struct is_void<void> : public true_type  {};

/// is_array
template<typename>             struct is_array       : public false_type {};
template<typename T, size_t S> struct is_array<T[S]> : public true_type  {};
template<typename T>           struct is_array<T[]>  : public true_type  {};

/// is_function
template<typename T>                struct is_function                           : public false_type {};
template<typename T, typename... A> struct is_function<T(A...)>                  : public true_type  {};
template<typename T, typename... A> struct is_function<T(A......)>               : public true_type  {};
template<typename T, typename... A> struct is_function<T(A...)const>             : public true_type  {};
template<typename T, typename... A> struct is_function<T(A......)const>          : public true_type  {};
template<typename T, typename... A> struct is_function<T(A...)volatile>          : public true_type  {};
template<typename T, typename... A> struct is_function<T(A......)volatile>       : public true_type  {};
template<typename T, typename... A> struct is_function<T(A...)const volatile>    : public true_type  {};
template<typename T, typename... A> struct is_function<T(A......)const volatile> : public true_type  {};

/// is_refrence
template<typename T>
struct is_reference :
	public _ESTL_PRIV_PLACE::template_or<
		is_lvalue_reference<T>,
		is_rvalue_reference<T>>::type
{};

/*
 * Here we implement some of the more complicated type_traits
 * features, such as add_rvalue_refrence, is_convertible, and
 * declval.
 */
 /// add_rvalue_refrence
_ESTL_PRIV_BEGIN(_ESTL_PRIV_GLOBAL)
{
	/* 
	 * Implements the core system for 
	 * add_rvalue_refrence.
	 */
	template<typename T, bool = (!is_reference<T>::value && !is_void<T>::value)>
	struct add_rvalue_refrence_allow {
		typedef T type;
	};
	
	/*
	 * Template specialization for add_rvalue_refrence
	 * This adds the refrence (amp & ) to T
	 */
	template<typename T>
	struct add_rvalue_refrence_allow<T,true> {
		typedef T& type;
	};
}

template<typename T>
struct add_rvalue_refrence : public _ESTL_PRIV_PLACE::add_rvalue_refrence_allow<T> {};

/// declval
_ESTL_PRIV_BEGIN(_ESTL_PRIV_GLOBAL)
{
	/*
	 * Implements the core protection scheme
	 * for declval.
	 */
	template<typename T>
	struct declval_allowed
	{
		static const bool stop = false;
		static typename add_rvalue_refrence<T>::type delegate();
	};
}

template<typename T>
inline typename add_rvalue_refrence<T>::type declval() noexcept
{
	static_assert(
		_ESTL_PRIV_PLACE::declval_allowed<T>::stop,
		"declval() must not be used!"
	);
	return _ESTL_PRIV_PLACE::declval_allowed<T>::delegate();
}

/// is_convertible
_ESTL_PRIV_BEGIN(_ESTL_PRIV_GLOBAL)
{
	/*
	 * Implements the core features required
	 * to implement is_convertible
	 */
	template<
		typename T1,
		typename T2,
		bool = is_void    <T1>::value || \
			   is_function<T2>::value || \
			   is_array   <T2>::value> 
	struct is_convertible_allowed {
		static const bool priv_value = is_void<T2>::value;
	};
	
	/*
	 * Type specific covertible type
	 */
	struct is_convertible_type {
		typedef char                         type_one;
		typedef struct { char priv_arr[2]; } type_two;
	};
	
	/*
	 * Actual checking implementation for is_convertible
	 */
	template<typename T1, typename T2>
	class is_convertible_allowed<T1,T2,false> : public is_convertible_type
	{
	private:
		template<typename C1>
		static void testaux(C1);
		
		/*
		 * Requires declval()
		 */
		template<typename C1, typename C2>
		static decltype (
			testaux<C1>(declval<C2>()),
			type_two()
		) test(int);
		
		
		template<typename, typename>
		static type_one test(...);
	public:
		static const bool value = (
			sizeof(test<T1,T2>(0)) == 1
		);
	};
}

/// is_convertible
template<typename T1, typename T2>
struct is_convertible : public integral_constant<
	bool,
	_ESTL_PRIV_PLACE::is_convertible_allowed<T1,T2>::value>
{};

_ESTL_CLOSE_NAMESPACE
#endif
