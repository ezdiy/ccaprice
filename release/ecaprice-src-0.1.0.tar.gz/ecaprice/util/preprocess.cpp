#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>

struct fmt {
    operator const std::string() const { return m_ss.str(); }
    template<typename T>
    fmt& operator,(const T& rhs) { m_ss << rhs ; return *this; }
    std::stringstream m_ss; 
};

std::vector<std::string> &split(const std::string&s, char delim, std::vector<std::string>& e)
{
    std::string items_split;
    std::stringstream ss(s);
    while(std::getline(ss, items_split, delim))
        e.push_back(items_split);
}

int main(int argc, char **argv)
{
    std::size_t   l;
    std::string   t;
    std::ifstream i; i.open((argv[1] != NULL) ? argv[1] : "", std::ios::in);

    std::string::size_type   findpre;
    std::vector<std::string> slines;
    std::vector<std::string> tokens;

    // create filename for prepreprocessor inclusions
    std::string filename[2] = {
        (argv[1] != NULL) ? argv[1] : "", filename[0]
    };
    filename[0] = filename[0].substr(  (filename[0].find_last_of ("/")+1)); // remove directories
    filename[0] = filename[0].substr(0,(filename[0].find_first_of(".")+0)); // remove extension
    filename[1] = filename[0];
    // make proper-case
    for (std::size_t i = 0; i < filename[0].size(); i++)
    {
        filename[0][i] = toupper(filename[0][i]);
        filename[1][i] = tolower(filename[1][i]);
    }

    slines.push_back((fmt(), "#ifdef ECAPRICE_PREPROCESSED_", filename[0]));
    slines.push_back((fmt(), "\t#undef ECAPRICE_PREPROCESSED_", filename[0]));
    slines.push_back("#endif");
    slines.push_back((fmt(), "#define ECAPRICE_PREPROCESSED_", filename[0], " 0x01"));
    slines.push_back("// This file has been preprocessed by the ecaprice pre-preprocessor, this source is not to be modified!");
    while(i.good() && std::getline(i, t)) {
        if((findpre = t.find("// { pre:d }")) != std::string::npos) {
            split(t.substr(findpre + 13), ',', tokens);
            for(std::vector<std::string>::iterator it = tokens.begin(); it != tokens.end(); ++it) {
                slines.push_back((fmt(), "#ifdef "   , *it));
                slines.push_back((fmt(), "#warning \"`", *it, "` cannot be defined, undefining it, this could break functionality. Please consider using an alternitive instead of: ", *it, "\""));
                slines.push_back((fmt(), "#undef "   , *it));
                slines.push_back("#endif");
            }
        }
        else if((findpre = t.find("NULL")) != std::string::npos) {
            slines.push_back((fmt(), "#warning { NULL used, perhaps you meant 0 or nullptr? @ line: ", l+1, " <", filename[1], ">"));
            slines.push_back(t);
        }
        else if((findpre = t.find("{ pre:i }")) != std::string::npos) {
            slines.push_back((fmt(), "#warning { <", filename[1], "> is incomplete, and could be missing things from the standard library. } "));
            slines.push_back("// TODO, finish");
        }
        else {
            slines.push_back(t);
        }
        l ++;
    }
    for(std::vector<std::string>::iterator it = slines.begin(); it != slines.end(); ++it)
        std::cout << *it << std::endl;
}
