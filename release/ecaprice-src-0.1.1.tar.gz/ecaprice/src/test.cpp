#include "inc/all"

estl::vector<int> vdata;
void test() { estl::cout << "Called TEST!!" << estl::endl; }

void ilist(const estl::initializer_list<int>& d) {
	for (estl::initializer_list<int>::const_iterator it = d.begin(); it != d.end(); ++it)
		estl::cout << *it << ", ";
}

int main()
{
    estl::cout << "This is a test" << estl::endl;
    estl::string data("this is a string");

    estl::cout << "STRING: " << data.c_str() << estl::endl;
    data += " this is more data on a string"; // a const char
    data += '.'; // a single char
    data += estl::string(" more data"); // an estl::string

    estl::cout << "STRING: " << data.c_str() << estl::endl;
    estl::cout << "MAX_INT: " << estl::numeric_limits<int>::max() << estl::endl;

    estl::pair<estl::string, void (*)()>  mypair = estl::make_pair(estl::string("WORK"), &test);
    estl::cout << mypair.first << estl::endl;
    mypair.second();
    
    vdata.push_back(100);
    vdata.push_back(200);
    estl::cout << "0: " << vdata[0]     << estl::endl;
    estl::cout << "1: " << vdata[1]     << estl::endl;
    estl::cout << "S: " << vdata.size() << estl::endl;

	estl::cout << "testing vector iterator" << estl::endl;
	for(estl::vector<int>::const_iterator it = vdata.begin(); it != vdata.end(); ++it)
		estl::cout << *it << ", ";
	estl::cout << estl::endl;

	ilist({1,2,3});
	
	estl::cout << "testing array" << estl::endl;
	estl::array<int, 10> aarray = {{1,2,3,4,5,6,7,8,9,0}};
	for(estl::array<int,10>::const_iterator it = aarray.begin(); it != aarray.end(); ++it)
		estl::cout << *it << ", ";
	estl::cout << estl::endl;
	estl::set_new_handler([]()->void{estl::cout<<"failed to allocate"<<estl::endl;});
	int *p = new int[500];
	
	int *v = new int [vdata.size()];
	estl::raw_storage_iterator<int*,int> raw(v);
	estl::copy(vdata.begin(), vdata.end(), raw);
	
	for(size_t i=0; i<vdata.size(); i++)
		estl::cout << "raw_storgae_iter: " << v[i] << estl::endl;
		
	estl::string a("testing 123 abc, defg");
	estl::cout << "string test: " << a << estl::endl;
	delete[] p;
	delete[] v;
	
	int  l[] ={1,2,3};
	int *r = new int[3];
	estl::uninitialized_copy(l, l+3, r);
	for(int i=0; i < 3; i++)
	{
		estl::cout << "uninitialized_copy: " << r[i] << estl::endl;
	}
	delete[] r;
	
    return 0;
}
