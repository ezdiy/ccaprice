/**
Copyright 2011 Dale Weiler. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Dale Weiler ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Dale Weiler OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Dale Weiler.
**/

#include "../inc/numeric"
#include "../inc/iostream"
#include "ut.hpp"

DEFTEST(accumulate,{
	int data[] = {10,20,30}; //10+20+30 = 60
	int accu   = estl::accumulate(data, data+3, 0);
	estl::cout << "  accumulate:             " << accu << estl::endl;
	DEFASSERT(
		(accu!=60),
		"accumulate: failed to accumulate data to 60"
	);
});
DEFTEST(accumulate_predicate,{
	int data[] = {10,20,30}; //10+20+30 = 60
	int accu   = estl::accumulate(data, data+3, 0,
		[](int x, int y)->int {
			return x+y;
		}
	);
	estl::cout << "  accumulate(p):          " << accu << estl::endl;
	DEFASSERT(
		(accu!=60),
		"accumulate(p): failed to accumulate data to 60"
	);
});
DEFTEST(adjacent_difference,{
	int data[] = {1,2,3,5,9,11,12};
	int result[7];
	estl::adjacent_difference(data, data+7, result);
	estl::cout << "  adjacent_difference:    ";
	for(int i=0; i<7; i++)
		estl::cout << result[i] << " ";
	estl::cout << estl::endl;
	DEFASSERT(
		(result[0]!=1 ||
		 result[1]!=1 ||
		 result[2]!=1 ||
		 result[3]!=2 ||
		 result[4]!=4 ||
		 result[5]!=2 ||
		 result[6]!=1),
		 "adjacent_difference: failed to return {1,1,1,2,4,2,1}"
	); 
});
DEFTEST(adjacent_difference_predicate,{
	int data[] = {1,2,3,5,9,11,12};
	int result[7];
	estl::adjacent_difference(data, data+7, result,
		[](int x, int y) -> int {
			return x+y;
		}
	);
	estl::cout << "  adjacent_difference(p): ";
	for(int i=0; i<7; i++)
		estl::cout << result[i] << " ";
	estl::cout << estl::endl;
	DEFASSERT(
		(result[0]!=1  ||
		 result[1]!=3  ||
		 result[2]!=5  ||
		 result[3]!=8  ||
		 result[4]!=14 ||
		 result[5]!=20 ||
		 result[6]!=23),
		 "adjacent_difference(p): failed to return {1,1,1,2,4,2,1}"
	);
});
DEFTEST(inner_product,{
	int init      =100,store=0;
	int data[2][3]={{10,20,30},{1,2,3}};
	store = estl::inner_product(data[0], data[0]+3, data[1], init);
	estl::cout << "  inner_product:          " << store << estl::endl;
	DEFASSERT(
		(store!=240),
		"inner_product: failed to return 240 for {{10,20,30},{1,2,3}}"
	);
});
DEFTEST(inner_product_predicate,{
	int init      =100,store=0;
	int data[2][3]={{10,20,30},{1,2,3}};
	store = estl::inner_product(data[0], data[0]+3, data[1], init,
		[](int x, int y)->int{
			return x-y;
		},
		[](int x, int y)->int{
			return x+y;
		}
	);
	estl::cout << "  inner_product(p):       " << store << estl::endl;
	DEFASSERT(
		(store!=34),
		"inner_product(p): failed to return 34 for {{10,20,30},{1,2,3}} [accumulate x-y] [product x+y]"
	);
});
DEFTEST(partial_sum,{
	int value[] = {1,2,3,4,5};
	int store[5];
	estl::partial_sum(value, value+5, store);
	estl::cout << "  partial_sum:            ";
	for(int i=0; i<5; i++)
		estl::cout << store[i] << " ";
	estl::cout << estl::endl;
	DEFASSERT(
		(store[0]!=1  ||
		 store[1]!=3  ||
		 store[2]!=6  ||
		 store[3]!=10 ||
		 store[4]!=15),
		 "partial_sum: failed to return {1,3,6,10,15} for {1,2,3,4,5}"
	);
});
DEFTEST(partial_sum_predicate,{
	int value[] = {1,2,3,4,5};
	int store[5];
	estl::partial_sum(value, value+5, store,
		[](int x, int y)->int{
			return x+y+1;
		}
	);
	estl::cout << "  partial_sum(p):         ";
	for(int i=0; i<5; i++)
		estl::cout << store[i] << " ";
	estl::cout << estl::endl;
	DEFASSERT(
		(store[0]!=1  ||
		 store[1]!=4  ||
		 store[2]!=8  ||
		 store[3]!=13 ||
		 store[4]!=19),
		 "partial_sum(p): failed to return {1,4,8,13,19} for {1,2,3,4,5} using predicate[x+y+1]"
	);
});
DEFTEST_SUITE();
